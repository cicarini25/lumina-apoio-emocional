package com.lumiapp.apoioemocional;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
