# Validação do ícone da Lumina

A validação publicada foi realizada em 18 de agosto de 2026.

O asset quadrado de 512x512 foi aberto no domínio público do app e apresentou o símbolo da Lumina sem texto: perfil feminino com cabelo violeta, arco dourado, estrela luminosa e fundo azul-marinho/violeta. URL pública consultada: https://lumiapp-lqtmuzbz.manus.space/manus-storage/lumina-app-icon-512_dc572071.png

O manifest foi consultado no domínio publicado: https://lumiapp-lqtmuzbz.manus.space/manifest.webmanifest. O projeto declara o nome Lumina, o slogan, display standalone, orientação portrait-primary, tema #7b2cbf e os dois arquivos de ícone com tamanhos declarados 192x192 e 512x512.

Os caminhos usados no manifest são:

- /manus-storage/lumina-app-icon-192_01b639d4.png — 192x192, image/png
- /manus-storage/lumina-app-icon-512_dc572071.png — 512x512, image/png

A home responsiva também foi verificada no viewport mobile 375x812 após a integração, sem alteração visual indesejada.

## Validação da abertura pulsante

A tela de abertura foi capturada diretamente no preview com a splash ainda visível em dois tamanhos. Em mobile (375x812), a arte completa da Lumina aparece centralizada dentro de um cartão translúcido, com as escritas abaixo do símbolo preservadas e o slogan abaixo da imagem. Em desktop (1280x720), a mesma composição permanece centralizada, proporcional e legível. A animação usa entrada por opacidade e pulso de escala entre 0.94 e 1.035, com fallback estático para usuários que preferem reduzir movimento. A duração final foi restaurada para 1,9 segundo após a validação.

## Novo fluxo de abertura principal

A splash independente foi removida. A página principal agora começa diretamente com a arte completa da Lumina, incluindo as escritas incorporadas na imagem e o slogan abaixo, antes do conteúdo do hero. A composição foi validada em 375x812 e 1280x720. O logotipo usa a classe `lumi-logo-pulse-7s`, com animação única de 7 segundos; após o ciclo, permanece estável. A preferência `prefers-reduced-motion` desativa a animação e mantém a arte visível sem movimento.

## Fluxo separado confirmado

A primeira tela mostra apenas a arte completa da Lumina em um cartão central, com pulso de 7 segundos. Após a transição automática, a segunda tela exibe o conteúdo principal — navegação, slogan, mensagem de acolhimento, CTA, afirmação e recursos — sem a imagem/cartão do logotipo. A transição foi confirmada no preview local; o DOM da segunda tela contém “Um espaço seguro para o que você sente” e não contém `.lumi-opening-logo`.

## Capturas explícitas nos dois viewports

Foram capturadas as duas telas em conjunto nos viewports mobile (375x812) e desktop (1280x720). Em `/`, a capa mostra exclusivamente a arte completa da Lumina. Em `/?skipOpening=1`, a segunda página mostra o hero, CTA e conteúdo principal sem o cartão da logo. O parâmetro de pré-visualização é usado apenas para validação visual; o fluxo normal continua transitando automaticamente após 7 segundos.
