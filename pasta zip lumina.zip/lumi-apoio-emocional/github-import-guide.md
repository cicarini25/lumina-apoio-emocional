# Guia de Importação para o GitHub — Lumina

Como a integração direta por OAuth com o GitHub pode encontrar bloqueios de pop-up ou permissão no navegador, o método mais rápido, seguro e garantido para enviar o projeto **Lumina** para o seu repositório GitHub é a importação manual do código-fonte.

## Passo a Passo

### 1. Criar o Repositório no GitHub
1. Acesse [GitHub](https://github.com) e faça login na sua conta.
2. Clique no botão **`+`** no canto superior direito e selecione **New repository**.
3. Defina o nome do repositório como **`lumina-apoio-emocional`**.
4. Escolha **Public** ou **Private** conforme sua preferência.
5. **NÃO** marque a opção de adicionar arquivo README, .gitignore ou licença (o projeto já contém esses arquivos).
6. Clique em **Create repository**.

### 2. Baixar o Código Limpo da Lumina
1. No painel de gerenciamento do projeto na plataforma, clique no botão de download (três pontos `...` ou opção **Download as ZIP**).
2. Salve o arquivo compactado no seu computador e descompacte-o em uma pasta de sua preferência.

### 3. Enviar para o GitHub via Linha de Comando (ou GitHub Desktop)
Abra o terminal (Prompt de Comando, PowerShell ou Terminal do Mac) na pasta descompactada do projeto e execute os comandos abaixo:

```bash
git init
git add .
git commit -m "feat: versão inicial completa da Lumina - apoio emocional e comunidade"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/lumina-apoio-emocional.git
git push -u origin main
```
*(Substitua `SEU_USUARIO` pelo seu nome de usuário real no GitHub).*

### Alternativa com o GitHub Desktop:
1. Abra o **GitHub Desktop**.
2. Vá em **File > Add Local Folder...** e selecione a pasta descompactada da Lumina.
3. Clique em **Publish repository**, confirme o nome `lumina-apoio-emocional` e clique em **Publish Repository**.
