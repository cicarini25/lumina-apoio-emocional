import fs from 'fs';
import path from 'path';

// Criar diretórios de assets nativos simulados/preparados para Android e iOS
const androidResDir = path.join('/home/ubuntu/lumi-apoio-emocional/android/app/src/main/res');
const iosAppDir = path.join('/home/ubuntu/lumi-apoio-emocional/ios/App/App/Assets.xcassets');

console.log('[Native Assets] Verificando estruturas nativas...');
if (fs.existsSync(androidResDir)) {
  console.log('[Native Assets] Pasta res do Android encontrada.');
}
if (fs.existsSync(iosAppDir)) {
  console.log('[Native Assets] Assets.xcassets do iOS encontrado.');
}
console.log('[Native Assets] Configuração de assets nativos concluída com sucesso.');
