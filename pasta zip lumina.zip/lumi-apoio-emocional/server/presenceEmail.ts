import { ENV } from "./_core/env";

type PresenceEmailInput = {
  code: string;
  recipient: string;
  appUrl: string;
};

export function buildPresenceEmail({ code, recipient, appUrl }: PresenceEmailInput) {
  const safeCode = code.replace(/[^0-9]/g, "").slice(0, 6);
  const safeRecipient = recipient.trim();
  const safeAppUrl = appUrl.replace(/\/$/, "");

  return {
    to: [safeRecipient],
    subject: "Confirme sua presença na Lumina",
    html: `
      <div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:32px;color:#2b2140;background:#fffaff">
        <div style="padding:28px;border-radius:24px;background:linear-gradient(135deg,#7c3aed,#db2777);color:#fff">
          <p style="margin:0 0 8px;font-size:12px;letter-spacing:3px;font-weight:700">LUMINA</p>
          <h1 style="margin:0;font-size:28px">Confirme sua presença</h1>
          <p style="margin:14px 0 0;line-height:1.6">Recebemos uma tentativa de acesso à sua conta. Use o código abaixo para continuar com segurança.</p>
        </div>
        <div style="padding:28px 8px;text-align:center">
          <p style="margin:0 0 10px;color:#6b6475">Seu código de confirmação</p>
          <div style="display:inline-block;padding:14px 24px;border-radius:16px;background:#f2eafe;color:#6d28d9;font-size:32px;letter-spacing:8px;font-weight:700">${safeCode}</div>
          <p style="margin:20px 0 0;color:#6b6475;line-height:1.6">Esse código expira em 10 minutos. Se você não tentou entrar, ignore este e-mail e altere sua senha.</p>
          <a href="${safeAppUrl}" style="display:inline-block;margin-top:22px;color:#6d28d9;font-weight:700">Abrir a Lumina</a>
        </div>
        <p style="margin:24px 0 0;font-size:12px;color:#8d8796;text-align:center">Este é um e-mail automático de segurança da Lumina. Nunca compartilhe seu código.</p>
      </div>
    `,
  };
}

export async function sendPresenceEmail({ code, recipient }: Omit<PresenceEmailInput, "appUrl">): Promise<boolean> {
  if (!ENV.resendApiKey || !ENV.resendFromEmail) {
    console.warn("[Lumina Auth] RESEND_API_KEY ou RESEND_FROM_EMAIL não configurado; e-mail não enviado.");
    return false;
  }

  const message = buildPresenceEmail({ code, recipient, appUrl: ENV.appUrl });
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${ENV.resendApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: ENV.resendFromEmail,
      to: message.to,
      subject: message.subject,
      html: message.html,
    }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    console.error("[Lumina Auth] Falha ao enviar e-mail de presença:", response.status, detail.slice(0, 240));
    return false;
  }

  return true;
}
