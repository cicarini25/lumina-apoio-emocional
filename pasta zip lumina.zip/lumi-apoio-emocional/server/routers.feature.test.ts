import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

// Mock do banco e da LLM para testar os routers isoladamente
vi.mock("./db", () => ({
  createConversation: vi.fn(async () => 42),
  getUserConversations: vi.fn(async () => [
    { id: 1, userId: 1, title: "Conversa", topic: "geral", createdAt: new Date(), updatedAt: new Date() },
  ]),
  getConversationById: vi.fn(async (id: number, userId: number) =>
    id === 1 && userId === 1
      ? { id: 1, userId: 1, title: "Nova conversa", topic: "saude_emocional", createdAt: new Date(), updatedAt: new Date() }
      : undefined,
  ),
  getConversationMessages: vi.fn(async () => []),
  addMessage: vi.fn(async () => 100),
  updateConversationTitle: vi.fn(async () => undefined),
  touchConversation: vi.fn(async () => undefined),
  deleteConversation: vi.fn(async (id: number) => id === 1),
  getUserSettings: vi.fn(async () => undefined),
  upsertUserSettings: vi.fn(async () => undefined),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(async () => ({
    choices: [{ message: { content: "Estou aqui com você. 💜" } }],
  })),
}));

import { invokeLLM } from "./_core/llm";
import * as db from "./db";
import { appRouter } from "./routers";

function createCtx(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "user-1",
      email: "u@example.com",
      name: "Usuária Teste",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as unknown as TrpcContext["res"],
  };
}

beforeEach(() => {
  vi.clearAllMocks();
});

describe("conversations router", () => {
  it("lista as conversas do usuário", async () => {
    const caller = appRouter.createCaller(createCtx());
    const list = await caller.conversations.list();
    expect(list).toHaveLength(1);
    expect(db.getUserConversations).toHaveBeenCalledWith(1);
  });

  it("cria conversa com todos os temas válidos, título específico e saudação inicial da Lumina", async () => {
    const caller = appRouter.createCaller(createCtx());
    const topics = ["saude_emocional", "relacionamentos", "trabalho", "apoio_espiritual", "geral"] as const;

    for (const topic of topics) {
      const result = await caller.conversations.create({ topic });
      expect(result).toEqual({ id: 42 });
    }

    expect(db.createConversation).toHaveBeenCalledTimes(topics.length);
    expect(db.addMessage).toHaveBeenCalledTimes(topics.length);
  });

  it("rejeita tópico inválido", async () => {
    const caller = appRouter.createCaller(createCtx());
    // @ts-expect-error tópico propositalmente inválido
    await expect(caller.conversations.create({ topic: "invalido" })).rejects.toThrow();
  });

  it("carrega o tópico, o título e a mensagem inicial da conversa para o chat", async () => {
    const caller = appRouter.createCaller(createCtx());
    vi.mocked(db.getConversationMessages).mockResolvedValueOnce([
      { id: 10, conversationId: 1, role: "assistant", content: "Olá, estou aqui com você.", createdAt: new Date() }
    ]);
    const result = await caller.conversations.get({ id: 1 });
    expect(result.conversation.topic).toBe("saude_emocional");
    expect(result.messages).toHaveLength(1);
    expect(result.messages[0].content).toContain("estou aqui com você");
  });

  it("retorna NOT_FOUND para conversa de outro usuário", async () => {
    const caller = appRouter.createCaller(createCtx());
    await expect(caller.conversations.get({ id: 999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("exclui conversa própria", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.conversations.delete({ id: 1 });
    expect(result).toEqual({ success: true });
  });
});

describe("chat router", () => {
  it("envia mensagem e retorna resposta empática da Lumina", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.chat.send({ conversationId: 1, content: "Hoje foi um dia pesado" });
    expect(result.reply).toContain("Estou aqui com você");
    expect(result.riskDetected).toBe(false);
    // Persiste mensagem do usuário e da assistente
    expect(db.addMessage).toHaveBeenCalledTimes(2);
  });

  it("detecta risco e sinaliza para exibir o CVV", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.chat.send({
      conversationId: 1,
      content: "não aguento mais viver",
    });
    expect(result.riskDetected).toBe(true);
    // O contexto enviado à LLM deve conter o protocolo de crise reforçado
    const llmCall = vi.mocked(invokeLLM).mock.calls[0][0];
    const systemMessage = llmCall.messages[0];
    expect(String(systemMessage.content)).toContain("PROTOCOLO DE CRISE");
  });

  it("recusa mensagem vazia", async () => {
    const caller = appRouter.createCaller(createCtx());
    await expect(caller.chat.send({ conversationId: 1, content: "" })).rejects.toThrow();
  });

  it("retorna afirmação diária publicamente", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.chat.dailyAffirmation();
    expect(result.affirmation.length).toBeGreaterThan(10);
  });
});

describe("settings router", () => {
  it("retorna null quando não há prompt customizado", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.settings.get();
    expect(result).toEqual({ customPersonaPrompt: null });
  });

  it("salva prompt customizado", async () => {
    const caller = appRouter.createCaller(createCtx());
    const result = await caller.settings.save({ customPersonaPrompt: "Seja poética." });
    expect(result).toEqual({ success: true });
    expect(db.upsertUserSettings).toHaveBeenCalledWith(1, "Seja poética.");
  });

  it("normaliza string vazia para null (restaura padrão)", async () => {
    const caller = appRouter.createCaller(createCtx());
    await caller.settings.save({ customPersonaPrompt: "   " });
    expect(db.upsertUserSettings).toHaveBeenCalledWith(1, null);
  });
});
