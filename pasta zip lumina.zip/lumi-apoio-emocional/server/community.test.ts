import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("Community Router", () => {
  it("should list posts and wellbeing videos successfully", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const posts = await caller.community.listPosts({});
    expect(Array.isArray(posts)).toBe(true);

    const videos = await caller.community.listVideos();
    expect(Array.isArray(videos)).toBe(true);
    expect(videos.length).toBeGreaterThan(0);
  });

  it("should protect the interactive chat for authenticated members", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    await expect(caller.community.listChatMessages()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.community.sendChatMessage({ content: "Olá, comunidade" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("should reject empty or oversized chat messages before persistence", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    await expect(caller.community.sendChatMessage({ content: "" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.community.sendChatMessage({ content: "x".repeat(501) })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("should enforce admin role for community message reports and deletion", async () => {
    const regularUserCaller = appRouter.createCaller({
      user: { id: 2, openId: "user-2", name: "Membro", email: "membro@test.com", role: "user" },
      req: {} as any,
      res: {} as any,
    });

    await expect(regularUserCaller.community.listMessageReports()).rejects.toThrow();
    await expect(regularUserCaller.community.deleteChatMessage({ messageId: 1 })).rejects.toThrow();
  });
});
