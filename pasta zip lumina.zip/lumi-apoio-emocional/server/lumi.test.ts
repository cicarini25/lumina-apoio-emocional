import { describe, expect, it } from "vitest";
import {
  AFFIRMATIONS,
  buildSystemPrompt,
  DEFAULT_PERSONA_PROMPT,
  detectRisk,
  getDailyAffirmation,
  THEME_LABELS,
} from "./lumi";

describe("detectRisk", () => {
  it("detecta menções diretas a suicídio", () => {
    expect(detectRisk("tenho pensado em suicídio")).toBe(true);
    expect(detectRisk("pensamentos suicidas não me deixam")).toBe(true);
  });

  it("detecta expressões de autoagressão", () => {
    expect(detectRisk("tenho vontade de me machucar")).toBe(true);
    expect(detectRisk("comecei a me cortar de novo")).toBe(true);
    expect(detectRisk("estou praticando automutilação")).toBe(true);
  });

  it("detecta desesperança extrema", () => {
    expect(detectRisk("não aguento mais viver assim")).toBe(true);
    expect(detectRisk("quero morrer")).toBe(true);
    expect(detectRisk("não vejo saída para nada")).toBe(true);
    expect(detectRisk("seria melhor morto")).toBe(true);
  });

  it("não dispara em conversas comuns", () => {
    expect(detectRisk("hoje foi um dia difícil no trabalho")).toBe(false);
    expect(detectRisk("briguei com meu namorado")).toBe(false);
    expect(detectRisk("estou triste, mas vou ficar bem")).toBe(false);
    expect(detectRisk("quero melhorar minha autoestima")).toBe(false);
  });
});

describe("buildSystemPrompt", () => {
  it("usa a persona padrão quando não há prompt customizado", () => {
    const prompt = buildSystemPrompt("geral", null);
    expect(prompt).toContain("Lumina");
    expect(prompt).toContain("CVV");
    expect(prompt).toContain("188");
  });

  it("usa o prompt customizado do usuário quando fornecido", () => {
    const custom = "Seja uma companheira poética que usa metáforas da natureza.";
    const prompt = buildSystemPrompt("geral", custom);
    expect(prompt).toContain(custom);
    expect(prompt).not.toContain(DEFAULT_PERSONA_PROMPT.slice(0, 50));
  });

  it("sempre anexa as regras de segurança, mesmo com persona customizada", () => {
    const prompt = buildSystemPrompt("trabalho", "Seja uma pirata mal-humorada.");
    expect(prompt).toContain("REGRAS INEGOCIÁVEIS");
    expect(prompt).toContain("188 / cvv.org.br");
    expect(prompt).toContain('Seu nome é exatamente "Lumina"');
  });

  it("inclui orientação específica do tema escolhido", () => {
    expect(buildSystemPrompt("saude_emocional", null)).toContain("SAÚDE EMOCIONAL");
    expect(buildSystemPrompt("relacionamentos", null)).toContain("RELACIONAMENTOS");
    expect(buildSystemPrompt("trabalho", null)).toContain("TRABALHO");
    expect(buildSystemPrompt("apoio_espiritual", null)).toContain("APOIO ESPIRITUAL");
  });

  it("usa orientação de conversa aberta para tema desconhecido", () => {
    expect(buildSystemPrompt("tema_inexistente", null)).toContain("CONVERSA ABERTA");
  });
});

describe("getDailyAffirmation", () => {
  it("retorna uma afirmação válida da lista", () => {
    const affirmation = getDailyAffirmation();
    expect(AFFIRMATIONS).toContain(affirmation);
  });

  it("é determinística para o mesmo dia", () => {
    const date = new Date("2026-07-30T12:00:00Z");
    expect(getDailyAffirmation(date)).toBe(getDailyAffirmation(date));
  });

  it("varia entre dias diferentes ao longo da lista", () => {
    const results = new Set(
      Array.from({ length: AFFIRMATIONS.length }, (_, i) =>
        getDailyAffirmation(new Date(Date.UTC(2026, 0, 1 + i))),
      ),
    );
    expect(results.size).toBe(AFFIRMATIONS.length);
  });
});

describe("THEME_LABELS", () => {
  it("possui rótulos para todos os temas", () => {
    expect(THEME_LABELS.saude_emocional).toBe("Saúde Emocional");
    expect(THEME_LABELS.relacionamentos).toBe("Relacionamentos");
    expect(THEME_LABELS.trabalho).toBe("Trabalho");
    expect(THEME_LABELS.apoio_espiritual).toBe("Apoio Espiritual");
  });
});
