import { beforeEach, describe, expect, it, vi } from "vitest";
import crypto from "node:crypto";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

const state: { user: any } = { user: undefined };

vi.mock("./db", () => ({
  getDb: vi.fn(async () => ({
    select: vi.fn(() => ({
      from: vi.fn(() => ({
        where: vi.fn(() => ({
          limit: vi.fn(async () => (state.user ? [state.user] : [])),
        })),
      })),
    })),
    insert: vi.fn(() => ({
      values: vi.fn(async (values: Record<string, unknown>) => {
        state.user = {
          id: 7,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: null,
          ...values,
        };
      }),
    })),
    update: vi.fn(() => ({
      set: vi.fn((patch: Record<string, unknown>) => ({
        where: vi.fn(async () => {
          if (state.user) state.user = { ...state.user, ...patch };
        }),
      })),
    })),
  })),
}));

vi.mock("./presenceEmail", () => ({
  sendPresenceEmail: vi.fn(async () => true),
}));

vi.mock("./googleClient", () => ({
  verifyGoogleIdToken: vi.fn(),
}));

import { appRouter } from "./routers";
import { verifyGoogleIdToken } from "./googleClient";
import { requireConfirmedAccount, sdk } from "./_core/sdk";

function createContext(res: TrpcContext["res"]): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res,
  };
}

function confirmedUser(isVerified: boolean): User {
  return {
    id: 7,
    openId: "social_google_subject-1",
    name: "Pessoa Lumina",
    email: "pessoa@example.com",
    phone: null,
    passwordHash: null,
    provider: "google",
    loginMethod: "google",
    role: "user",
    twoFactorCode: null,
    twoFactorMethod: "email_device",
    twoFactorExpiresAt: null,
    isVerified,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } as User;
}

describe("Lumina Auth — Google e confirmação de presença", () => {
  beforeEach(() => {
    state.user = undefined;
    vi.clearAllMocks();
    vi.mocked(verifyGoogleIdToken).mockResolvedValue({
      subject: "subject-1",
      email: "pessoa@example.com",
      name: "Pessoa Lumina",
    });
  });

  it("realiza o login social diretamente sem exigir código de verificação", async () => {
    const cookie = vi.fn();
    const caller = appRouter.createCaller(createContext({ cookie } as any));

    const result = await caller.auth.local.socialLogin({
      provider: "google",
      idToken: "google-id-token-1234567890",
    });

    expect(result.requiresVerification).toBe(false);
    expect(result.userId).toBe(7);
    expect(state.user.isVerified).toBe(true);
    expect(cookie).toHaveBeenCalledOnce();
    expect(requireConfirmedAccount(state.user as User)).toEqual(state.user);
  });

  it("não cria sessão nem estado de usuário quando o token Google é inválido", async () => {
    vi.mocked(verifyGoogleIdToken).mockRejectedValueOnce(new Error("Conta Google inválida"));
    const caller = appRouter.createCaller(createContext({ cookie: vi.fn() } as any));

    await expect(
      caller.auth.local.socialLogin({
        provider: "google",
        idToken: "google-id-token-1234567890",
      }),
    ).rejects.toThrow("Conta Google inválida");

    expect(state.user).toBeUndefined();
  });

  it("mantém o bloqueio explícito para uma conta ainda não confirmada", () => {
    expect(() => requireConfirmedAccount(confirmedUser(false))).toThrow(
      "Account presence confirmation required",
    );
    expect(requireConfirmedAccount(confirmedUser(true)).isVerified).toBe(true);
  });
});

describe("Lumina Auth — login local sem SMS", () => {
  it("emite sessão diretamente após validar e-mail e senha", async () => {
    const passwordHash = crypto.createHmac("sha256", "lumina-secure-salt-2026").update("senha-segura").digest("hex");
    state.user = {
      id: 7,
      openId: "local_user-7",
      name: "Pessoa Lumina",
      email: "pessoa@example.com",
      phone: null,
      passwordHash,
      provider: "local",
      loginMethod: "email_password",
      twoFactorCode: "123456",
      twoFactorMethod: "sms_email",
      twoFactorExpiresAt: String(Date.now() + 600_000),
      isVerified: false,
    };

    const cookie = vi.fn();
    const caller = appRouter.createCaller(createContext({ cookie } as any));
    const result = await caller.auth.local.login({
      email: "pessoa@example.com",
      password: "senha-segura",
    });

    expect(result.requiresVerification).toBe(false);
    expect(result.emailSent).toBe(false);
    expect(cookie).toHaveBeenCalledOnce();
    const sessionToken = cookie.mock.calls[0]?.[1] as string;
    const verifiedSession = await sdk.verifySession(sessionToken);
    expect(verifiedSession).toMatchObject({
      openId: "local_user-7",
      name: "Pessoa Lumina",
    });
    expect(verifiedSession?.appId).toBeTruthy();
    expect(state.user.isVerified).toBe(true);
    expect(state.user.twoFactorCode).toBeNull();
    expect(state.user.twoFactorMethod).toBe("password");
  });
});

