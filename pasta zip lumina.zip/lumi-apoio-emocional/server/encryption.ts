import crypto from "node:crypto";
import { ENV } from "./_core/env";

const KEY_LENGTH = 32;
const IV_LENGTH = 12;
const AUTH_TAG_LENGTH = 16;
const DERIVATION_SALT = "lumina-encryption-v1";

function getEncryptionKey(): Buffer {
  const secret = ENV.encryptionKey.trim();
  if (!secret || secret.length < 32) {
    throw new Error("LUMINA_ENCRYPTION_KEY must contain at least 32 characters");
  }

  return crypto.scryptSync(secret, DERIVATION_SALT, KEY_LENGTH);
}

export function encryptText(value: string): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv("aes-256-gcm", getEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return ["v1", iv.toString("base64url"), authTag.toString("base64url"), ciphertext.toString("base64url")].join(".");
}

export function decryptText(value: string): string {
  if (!value.startsWith("v1.")) return value;

  const parts = value.split(".");
  if (parts.length !== 4) throw new Error("Invalid encrypted Lumina payload");

  const [, ivEncoded, tagEncoded, ciphertextEncoded] = parts;
  const iv = Buffer.from(ivEncoded, "base64url");
  const authTag = Buffer.from(tagEncoded, "base64url");
  const ciphertext = Buffer.from(ciphertextEncoded, "base64url");

  if (iv.length !== IV_LENGTH || authTag.length !== AUTH_TAG_LENGTH) {
    throw new Error("Invalid encrypted Lumina payload");
  }

  const decipher = crypto.createDecipheriv("aes-256-gcm", getEncryptionKey(), iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
}
