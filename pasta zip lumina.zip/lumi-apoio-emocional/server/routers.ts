import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { authLocalRouter } from "./routers/authLocal";
import { communityRouter } from "./routers/community";
import * as db from "./db";
import { buildSystemPrompt, detectRisk, getDailyAffirmation } from "./lumi";
const themeSchema = z.enum(["geral", "ansiedade", "relacionamento", "trabalho", "espiritual"]);

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    local: authLocalRouter,
  }),

  community: communityRouter,

  conversations: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserConversations(ctx.user.id)),

    create: protectedProcedure
      .input(z.object({ topic: z.enum(["geral", "saude_emocional", "relacionamentos", "trabalho", "apoio_espiritual"]).default("geral") }))
      .mutation(async ({ ctx, input }) => {
        const greetings: Record<string, string> = {
          saude_emocional: "Olá. Sinto muito que você esteja passando por um momento difícil. Estou aqui inteiramente para te ouvir, sem julgamentos. Como você está se sentindo agora?",
          relacionamentos: "Olá. Questões de relacionamento e convivência mexem muito com o nosso coração. Pode desabafar: o que está acontecendo?",
          trabalho: "Olá. Pressão no trabalho e burnout esgotam nossas energias. Estou aqui para te acolher. O que está pesando mais na sua rotina profissional?",
          apoio_espiritual: "Olá. Em momentos de incerteza, buscar paz interior e serenidade é um ato de coragem. Como posso te acompanhar hoje?",
          geral: "Olá! Que bom que você chegou. Este é um espaço seguro para você respirar e conversar sobre o que quiser. Como posso te ajudar?",
        };

        const initialTitleMap: Record<string, string> = {
          saude_emocional: "Saúde Emocional",
          relacionamentos: "Relacionamentos",
          trabalho: "Trabalho & Carreira",
          apoio_espiritual: "Paz & Apoio Espiritual",
          geral: "Conversa Aberta",
        };

        const greeting = greetings[input.topic] ?? greetings.geral;
        const initialTitle = initialTitleMap[input.topic] ?? "Conversa com a Lumina";

        const id = await db.createConversation({
          userId: ctx.user.id,
          topic: input.topic,
          title: initialTitle,
        });

        await db.addMessage({
          conversationId: id,
          role: "assistant",
          content: greeting,
        });

        return { id };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const conversation = await db.getConversationById(input.id, ctx.user.id);
        if (!conversation) throw new TRPCError({ code: "NOT_FOUND" });
        const msgs = await db.getConversationMessages(input.id);
        return { conversation, messages: msgs };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const ok = await db.deleteConversation(input.id, ctx.user.id);
        if (!ok) throw new TRPCError({ code: "NOT_FOUND" });
        return { success: true };
      }),
  }),

  chat: router({
    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          content: z.string().min(1).max(4000),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const conversation = await db.getConversationById(input.conversationId, ctx.user.id);
        if (!conversation) throw new TRPCError({ code: "NOT_FOUND" });

        const risk = detectRisk(input.content);

        await db.addMessage({
          conversationId: conversation.id,
          role: "user",
          content: input.content,
        });

        const history = await db.getConversationMessages(conversation.id);
        const settings = await db.getUserSettings(ctx.user.id);
        const systemPrompt = buildSystemPrompt(conversation.topic, settings?.customPersonaPrompt);

        // Se risco detectado, reforça o protocolo de crise no contexto
        const riskNote = risk
          ? "\n\nATENÇÃO: A última mensagem do usuário contém possíveis sinais de risco (autoagressão/suicídio/crise). Ative o PROTOCOLO DE CRISE: acolha a dor com imensa compaixão, informe o CVV (188 / cvv.org.br) e incentive a busca por ajuda profissional imediata, permanecendo presente."
          : "";

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt + riskNote },
            ...history.slice(-30).map(m => ({
              role: m.role as "user" | "assistant",
              content: m.content,
            })),
          ],
        });

        const rawContent = response.choices[0]?.message?.content;
        const assistantContent =
          typeof rawContent === "string" && rawContent.trim()
            ? rawContent
            : "Estou aqui com você. Pode me contar um pouco mais sobre o que está sentindo?";

        await db.addMessage({
          conversationId: conversation.id,
          role: "assistant",
          content: assistantContent,
        });

        // Gera título na primeira troca de mensagens
        if (conversation.title === "Nova conversa") {
          const title = input.content.slice(0, 60) + (input.content.length > 60 ? "…" : "");
          await db.updateConversationTitle(conversation.id, ctx.user.id, title);
        }
        await db.touchConversation(conversation.id);

        return { reply: assistantContent, riskDetected: risk };
      }),

    dailyAffirmation: publicProcedure.query(() => ({ affirmation: getDailyAffirmation() })),
  }),

  settings: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const settings = await db.getUserSettings(ctx.user.id);
      return { customPersonaPrompt: settings?.customPersonaPrompt ?? null };
    }),
    save: protectedProcedure
      .input(z.object({ customPersonaPrompt: z.string().max(8000).nullable() }))
      .mutation(async ({ ctx, input }) => {
        const value = input.customPersonaPrompt?.trim() ? input.customPersonaPrompt.trim() : null;
        await db.upsertUserSettings(ctx.user.id, value);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
