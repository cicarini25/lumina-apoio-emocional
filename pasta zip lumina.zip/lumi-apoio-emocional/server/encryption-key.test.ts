import { describe, expect, it } from "vitest";
import { decryptText, encryptText } from "./encryption";

describe("Lumina encryption secret", () => {
  it("derives a working AES-256 key from the configured secret", () => {
    expect(process.env.LUMINA_ENCRYPTION_KEY).toBeTruthy();

    const original = "Mensagem privada da Lumina";
    const encrypted = encryptText(original);

    expect(encrypted).not.toContain(original);
    expect(decryptText(encrypted)).toBe(original);
  });
});
