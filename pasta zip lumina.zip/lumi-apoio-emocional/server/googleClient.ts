export function normalizeGoogleClientId(value: string): string {
  return value.trim().replace(/^https?:\/\//i, "").replace(/\/+$/, "");
}

export function isGoogleClientId(value: string): boolean {
  return /^\d+-[a-z0-9-]+\.apps\.googleusercontent\.com$/i.test(normalizeGoogleClientId(value));
}

type GoogleIdentity = {
  subject: string;
  email: string;
  name: string;
  picture?: string;
};

export async function verifyGoogleIdToken(idToken: string): Promise<GoogleIdentity> {
  const configuredClientId = normalizeGoogleClientId(process.env.VITE_GOOGLE_CLIENT_ID ?? "");
  if (!isGoogleClientId(configuredClientId)) {
    throw new Error("Client ID do Google não está configurado corretamente.");
  }

  const response = await fetch(
    `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`,
  );
  if (!response.ok) {
    throw new Error("Não foi possível validar a conta Google.");
  }

  const claims = (await response.json()) as {
    aud?: string;
    sub?: string;
    email?: string;
    email_verified?: string;
    name?: string;
    picture?: string;
  };

  if (
    claims.aud !== configuredClientId ||
    !claims.sub ||
    !claims.email ||
    claims.email_verified !== "true"
  ) {
    throw new Error("A conta Google não pôde ser confirmada.");
  }

  return {
    subject: claims.sub,
    email: claims.email,
    name: claims.name?.trim() || claims.email.split("@")[0],
    picture: claims.picture,
  };
}
