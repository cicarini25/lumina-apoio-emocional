import { describe, expect, it } from "vitest";
import { isGoogleClientId, normalizeGoogleClientId } from "./googleClient";

describe("Google OAuth client configuration", () => {
  it("reaches the Google Identity Services endpoint with the configured client id", async () => {
    const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
    expect(clientId).toBeTruthy();
    const normalizedClientId = normalizeGoogleClientId(clientId ?? "");
    expect(isGoogleClientId(normalizedClientId)).toBe(true);

    const response = await fetch(
      `https://accounts.google.com/.well-known/openid-configuration?client_id=${encodeURIComponent(normalizedClientId)}`,
    );

    expect(response.ok).toBe(true);
  }, 15_000);
});
