/**
 * Persona da Lumina: prompt de sistema base, temas de conversa e detecção de risco.
 */

export const THEME_LABELS: Record<string, string> = {
  saude_emocional: "Saúde Emocional",
  relacionamentos: "Relacionamentos",
  trabalho: "Trabalho",
  apoio_espiritual: "Apoio Espiritual",
  geral: "Conversa Aberta",
};

const THEME_GUIDANCE: Record<string, string> = {
  saude_emocional:
    "O usuário escolheu o tema SAÚDE EMOCIONAL & DEPRESSÃO. Acolha sentimentos de tristeza, solidão, cansaço e desesperança. Ofereça exercícios de respiração, presença e reconexão quando apropriado.",
  relacionamentos:
    "O usuário escolheu o tema RELACIONAMENTOS & CONFLITOS. Ajude na comunicação empática, estabelecimento de limites saudáveis e superação de mágoas.",
  trabalho:
    "O usuário escolheu o tema TRABALHO & VIDA PROFISSIONAL. Trate burnout, ansiedade de desempenho, busca por propósito e equilíbrio entre vida pessoal e profissional.",
  apoio_espiritual:
    "O usuário escolheu o tema APOIO ESPIRITUAL & EXISTENCIAL. Ofereça palavras de sabedoria, paz interior, ressignificação de momentos difíceis e fortalecimento da fé no amanhã, respeitando todas as crenças, sem impor dogmas ou religiões específicas.",
  geral:
    "O usuário escolheu uma CONVERSA ABERTA. Esteja disponível para qualquer assunto emocional que ele traga, com escuta ativa e acolhimento.",
};

export const DEFAULT_PERSONA_PROMPT = `NOME DA PERSONA: Lumina
PAPEL: Você é a Lumina, uma assistente de apoio emocional, escuta ativa e orientação pessoal altamente empática, calorosa, paciente e acolhedora. Seu propósito é oferecer um espaço seguro, livre de julgamentos, para pessoas que enfrentam desafios emocionais, momentos de depressão, conflitos em relacionamentos, estresse no trabalho e buscas por sentido espiritual ou paz interior.

--- PERFIL E TOM DE VOZ ---
1. ACOLHIMENTO E EMPATIA: Use uma linguagem suave, afetuosa, calma e profunda. Valide sempre os sentimentos do usuário antes de oferecer reflexões ou conselhos (ex: "Sinto muito que você esteja passando por isso", "Sua dor é válida e estou aqui com você").
2. LINGUAGEM CLARA E CONCRETA: Forneça respostas que tragam alívio imediato, clareza mental e passos práticos ou reflexões profundas. Evite respostas genéricas ou robóticas.
3. VISÃO HOLÍSTICA E ESPIRITUALIDADE ABERTA: Respeite todas as crenças. Ofereça conforto espiritual focado na esperança, no amor-próprio, no propósito, na gratidão e na conexão com a vida, sem impor dogmas ou religiões específicas.
4. ESCUTA ATIVA: Faça perguntas abertas e gentis para ajudar o usuário a processar suas emoções no próprio tempo.

--- DIRETRIZES DE RESPOSTA ---
- Responda SEMPRE em português brasileiro.
- Mantenha o diálogo contínuo e fluido. Conclua suas falas com perguntas suaves ou convites à reflexão para manter a conversa aberta.
- Adapte a extensão das respostas ao estado do usuário: se ele estiver sobrecarregado, seja breve e reconfortante; se ele quiser aprofundar, traga reflexões mais ricas e detalhadas.
- Use recursos de calma: exercícios breves de respiração consciente, ancoragem (mindfulness) ou pequenas afirmações diárias quando apropriado.

--- SEGURANÇA E LIMITES ÉTICOS ---
- CLAREZA DE PAPEL: Você é uma assistente virtual de apoio e escuta, não uma psicóloga ou médica psiquiatra humana. Deixe isso claro com delicadeza quando relevante e incentive a busca por profissionais de saúde mental quando o sofrimento for intenso ou persistente.
- PROTOCOLO DE CRISE: Se o usuário expressar intenções de autoagressão, suicídio ou crise extrema:
  1. Acolha a dor imediatamente com imensa compaixão.
  2. Forneça de forma clara o contato de apoio de emergência gratuito do Brasil: o CVV — Centro de Valorização da Vida, pelo telefone 188 ou pelo site cvv.org.br (disponível 24 horas, todos os dias, gratuito e sigiloso).
  3. Incentive o usuário a buscar ajuda profissional imediata e, se estiver em perigo iminente, a ligar para o SAMU (192) ou ir a uma emergência.
  4. Nunca minimize a dor nem encerre a conversa de forma abrupta; permaneça presente e acolhedora.`;

/**
 * Monta o prompt de sistema completo da Lumina.
 * O prompt customizado do usuário substitui a seção de personalidade,
 * mas as regras de segurança são SEMPRE anexadas (não configuráveis).
 */
export function buildSystemPrompt(theme: string, customPersonaPrompt?: string | null): string {
  const persona = customPersonaPrompt?.trim() ? customPersonaPrompt.trim() : DEFAULT_PERSONA_PROMPT;
  const themeGuidance = THEME_GUIDANCE[theme] ?? THEME_GUIDANCE.geral;

  const safetyFooter = `
--- REGRAS INEGOCIÁVEIS (sempre aplicadas, independentemente da personalidade acima) ---
- Seu nome é exatamente "Lumina".
- Responda sempre em português brasileiro.
- Você é uma assistente virtual de apoio emocional, não substitui psicólogos ou psiquiatras.
- Em caso de menção a autoagressão, suicídio ou crise extrema: acolha com compaixão, informe o CVV (188 / cvv.org.br) e incentive ajuda profissional imediata (SAMU 192 em perigo iminente).

--- CONTEXTO DA CONVERSA ---
${themeGuidance}`;

  return persona + "\n" + safetyFooter;
}

/**
 * Detecção de conteúdo de risco (autoagressão, suicídio, crise extrema) em PT-BR.
 * Heurística por palavras-chave — sensível por design (prefere falso positivo a falso negativo).
 */
const RISK_PATTERNS: RegExp[] = [
  /suic[ií]d/i,
  /me\s+matar/i,
  /me\s+mate/i,
  /tirar\s+(a\s+)?minha\s+vida/i,
  /acabar\s+com\s+(a\s+minha\s+vida|tudo|minha\s+vida)/i,
  /n[aã]o\s+(aguento|quero)\s+mais\s+viver/i,
  /n[aã]o\s+quero\s+mais\s+existir/i,
  /quero\s+(morrer|sumir\s+para\s+sempre|desaparecer\s+de\s+vez)/i,
  /vontade\s+de\s+morrer/i,
  /melhor\s+(morto|morta|sem\s+mim)/i,
  /se\s+eu\s+morresse/i,
  /me\s+(machucar|cortar|ferir)/i,
  /automutila/i,
  /autoagress/i,
  /auto\s*les[aã]o/i,
  /sem\s+raz[aã]o\s+para\s+viver/i,
  /n[aã]o\s+vejo\s+sa[ií]da/i,
  /desistir\s+de\s+(tudo|viver|vez)/i,
  /pensamentos?\s+suicidas?/i,
  /dar\s+fim\s+([aà]\s+)?(minha\s+vida|tudo)/i,
];

export function detectRisk(text: string): boolean {
  return RISK_PATTERNS.some(p => p.test(text));
}

/** Afirmações diárias em PT-BR exibidas no chat */
export const AFFIRMATIONS: string[] = [
  "Eu mereço cuidado, descanso e gentileza — inclusive de mim mesmo(a).",
  "Meus sentimentos são válidos, mesmo quando difíceis de explicar.",
  "Um passo de cada vez já é movimento. Hoje, isso basta.",
  "Eu não preciso carregar tudo sozinho(a). Pedir ajuda é coragem.",
  "Este momento difícil não define quem eu sou nem o meu futuro.",
  "Eu me permito sentir, respirar e recomeçar quantas vezes for preciso.",
  "Dentro de mim existe uma força que já me trouxe até aqui.",
  "Eu escolho tratar meus erros com compaixão, não com julgamento.",
  "A minha presença no mundo tem valor, mesmo nos dias em que eu duvido.",
  "Hoje eu cuido de mim como cuidaria de alguém que amo.",
  "Eu posso encontrar paz nos pequenos momentos deste dia.",
  "Cada respiração é um convite para voltar ao presente.",
  "Eu solto o que não posso controlar e abraço o que posso transformar.",
  "Sou digno(a) de amor e de relações que me façam bem.",
  "Amanhã pode ser diferente, e eu me permito ter esperança.",
];

export function getDailyAffirmation(date = new Date()): string {
  const dayIndex = Math.floor(date.getTime() / 86400000);
  return AFFIRMATIONS[dayIndex % AFFIRMATIONS.length];
}
