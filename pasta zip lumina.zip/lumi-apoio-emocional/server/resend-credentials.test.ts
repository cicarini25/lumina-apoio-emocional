import { describe, expect, it } from "vitest";

describe("Resend credentials", () => {
  it("autentica a chave configurada no endpoint de domínios", async () => {
    const apiKey = process.env.RESEND_API_KEY;
    const fromEmail = process.env.RESEND_FROM_EMAIL;

    expect(apiKey, "RESEND_API_KEY não configurada").toMatch(/^re_[A-Za-z0-9_\-]+$/);
    expect(fromEmail, "RESEND_FROM_EMAIL não configurado").toMatch(/@/);

    // Uma chave restrita a envio não pode consultar /domains. Enviamos um
    // payload deliberadamente inválido para validar a autenticação sem
    // disparar um e-mail real; uma chave válida retorna erro de validação,
    // enquanto uma chave inválida retorna 401/403.
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: "invalid", to: [], subject: "Lumina credential check" }),
    });

    const detail = await response.text();
    expect(response.status, detail).not.toBe(401);
    expect(response.status, detail).not.toBe(403);
    expect(response.status, detail).toBeGreaterThanOrEqual(400);
    expect(response.status, detail).toBeLessThan(500);
  }, 15_000);
});

export {};

