import { z } from "zod";
import { getDb } from "../db";
import { users, messages } from "../../drizzle/schema";
import type { User } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "../_core/cookies";
import { ENV } from "../_core/env";
import { sdk } from "../_core/sdk";
import crypto from "crypto";
import { publicProcedure, router } from "../_core/trpc";
import { sendPresenceEmail } from "../presenceEmail";
import { verifyGoogleIdToken } from "../googleClient";

function hashPassword(password: string): string {
  const salt = "lumina-secure-salt-2026";
  return crypto.createHmac("sha256", salt).update(password).digest("hex");
}

async function createLocalSession(
  user: Pick<User, "openId" | "name" | "email">,
  req: Parameters<typeof getSessionCookieOptions>[0],
) {
  if (!ENV.cookieSecret) throw new Error("Configuração de sessão indisponível");

  const token = await sdk.signSession(
    {
      openId: user.openId,
      appId: ENV.appId,
      name: user.name || user.email || "Membro Lumina",
    },
    { expiresInMs: 30 * 24 * 60 * 60 * 1000 },
  );

  const cookieOptions = getSessionCookieOptions(req);
  return { token, cookieOptions };
}

export const authLocalRouter = router({
  register: publicProcedure
    .input(
      z.object({
        name: z.string().min(2, "Nome muito curto"),
        email: z.string().email("E-mail inválido"),
        phone: z.string().optional(),
        password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email))
        .limit(1);

      if (existing.length > 0) {
        throw new Error("Este e-mail já está cadastrado.");
      }

      const openId = `local_${crypto.randomUUID()}`;
      const passwordHash = hashPassword(input.password);

      await db.insert(users).values({
        openId,
        name: input.name,
        email: input.email,
        phone: input.phone,
        passwordHash,
        provider: "local",
        loginMethod: "email_password",
        role: "user",
        twoFactorCode: null,
        twoFactorMethod: "password",
        twoFactorExpiresAt: null,
        isVerified: true,
        lastSignedIn: new Date(),
      });

      const newUserRes = await db
        .select()
        .from(users)
        .where(eq(users.openId, openId))
        .limit(1);

      const user = newUserRes[0];
      if (!user) throw new Error("Não foi possível criar a conta.");
      const session = await createLocalSession(user, ctx.req);
      ctx.res.cookie(COOKIE_NAME, session.token, session.cookieOptions);

      return {
        success: true,
        requiresVerification: false,
        userId: user.id,
        email: user.email,
        phone: user.phone,
        emailSent: false,
      };
    }),

  login: publicProcedure
    .input(
      z.object({
        email: z.string().email("E-mail inválido"),
        password: z.string().min(1, "Digite sua senha"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email))
        .limit(1);

      if (existing.length === 0) {
        throw new Error("E-mail ou senha incorretos.");
      }

      const user = existing[0];
      const passwordHash = hashPassword(input.password);

      if (user.provider !== "local" || !user.passwordHash || user.passwordHash !== passwordHash) {
        throw new Error("E-mail ou senha incorretos.");
      }

      await db
        .update(users)
        .set({
          twoFactorCode: null,
          twoFactorExpiresAt: null,
          twoFactorMethod: "password",
          isVerified: true,
          lastSignedIn: new Date(),
        })
        .where(eq(users.id, user.id));

      const session = await createLocalSession(user, ctx.req);
      ctx.res.cookie(COOKIE_NAME, session.token, session.cookieOptions);

      return {
        success: true,
        requiresVerification: false,
        userId: user.id,
        email: user.email,
        phone: user.phone || "",
        emailSent: false,
      };
    }),

  verify2FA: publicProcedure
    .input(
      z.object({
        userId: z.number(),
        code: z.string().length(6, "O código deve ter 6 dígitos"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const res = await db
        .select()
        .from(users)
        .where(eq(users.id, input.userId))
        .limit(1);

      if (res.length === 0) {
        throw new Error("Usuário não encontrado.");
      }

      const user = res[0];

      if (!user.twoFactorCode || user.twoFactorCode !== input.code) {
        throw new Error("Código de verificação incorreto.");
      }

      const now = Date.now();
      if (user.twoFactorExpiresAt && parseInt(user.twoFactorExpiresAt) < now) {
        throw new Error("O código de verificação expirou. Solicite um novo.");
      }

      // Marcar como verificado
      await db
        .update(users)
        .set({
          isVerified: true,
          twoFactorCode: null,
          twoFactorExpiresAt: null,
          lastSignedIn: new Date(),
        })
        .where(eq(users.id, user.id));

      // Emitir sessão no mesmo formato validado pelo servidor
      const session = await createLocalSession(user, ctx.req);
      ctx.res.cookie(COOKIE_NAME, session.token, session.cookieOptions);

      return { success: true, user };
    }),

  resend2FA: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const res = await db
        .select()
        .from(users)
        .where(eq(users.id, input.userId))
        .limit(1);

      if (res.length === 0) throw new Error("Usuário não encontrado.");

      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = (Date.now() + 10 * 60 * 1000).toString();

      await db
        .update(users)
        .set({
          twoFactorCode: verificationCode,
          twoFactorExpiresAt: expiresAt,
        })
        .where(eq(users.id, input.userId));

      const emailSent = res[0].email ? await sendPresenceEmail({ code: verificationCode, recipient: res[0].email }) : false;
      if (ENV.isProduction && !emailSent) {
        throw new Error("Não foi possível reenviar o código de confirmação. Tente novamente mais tarde.");
      }

      return { success: true, emailSent, debugCode: ENV.isProduction ? undefined : verificationCode };
    }),

  forgotPassword: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const res = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email))
        .limit(1);

      if (res.length === 0) {
        // Por segurança, retornamos sucesso mesmo se o e-mail não existir
        return { success: true, message: "Se o e-mail estiver cadastrado, instruções foram enviadas." };
      }

      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      await db
        .update(users)
        .set({ twoFactorCode: resetCode })
        .where(eq(users.email, input.email));

      return { success: true, debugResetCode: resetCode };
    }),

  resetPassword: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        code: z.string().length(6),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");

      const res = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email))
        .limit(1);

      if (res.length === 0 || res[0].twoFactorCode !== input.code) {
        throw new Error("Código de recuperação inválido.");
      }

      const passwordHash = hashPassword(input.newPassword);
      await db
        .update(users)
        .set({ passwordHash, twoFactorCode: null })
        .where(eq(users.email, input.email));

      return { success: true };
    }),

  socialLogin: publicProcedure
    .input(
      z.object({
        provider: z.enum(["google", "apple", "facebook"]),
        idToken: z.string().min(20),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível");
      if (input.provider !== "google") {
        throw new Error("Este provedor ainda precisa ser configurado pela Lumina.");
      }

      const identity = await verifyGoogleIdToken(input.idToken);
      const openId = `social_google_${identity.subject}`;
      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, identity.email))
        .limit(1);

      let user;

      if (existing.length === 0) {
        await db.insert(users).values({
          openId,
          name: identity.name,
          email: identity.email,
          provider: "google",
          loginMethod: "google",
          role: "user",
          twoFactorCode: null,
          twoFactorMethod: "google",
          twoFactorExpiresAt: null,
          isVerified: true,
          lastSignedIn: new Date(),
        });
        const created = await db
          .select()
          .from(users)
          .where(eq(users.openId, openId))
          .limit(1);
        user = created[0];
      } else {
        user = existing[0];
        await db
          .update(users)
          .set({
            openId,
            name: identity.name,
            provider: "google",
            loginMethod: "google",
            twoFactorCode: null,
            twoFactorMethod: "google",
            twoFactorExpiresAt: null,
            isVerified: true,
            lastSignedIn: new Date(),
          })
          .where(eq(users.id, user.id));
      }

      const session = await createLocalSession(user, ctx.req);
      ctx.res.cookie(COOKIE_NAME, session.token, session.cookieOptions);

      return {
        success: true,
        requiresVerification: false,
        userId: user.id,
        email: user.email,
        phone: user.phone,
        provider: "google" as const,
        emailSent: false,
      };
    }),
});
