import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { getDb } from "../db";
import { communityPosts, communityComments, communityLikes, communityReports, communityMessages, communityMessageReports, wellbeingVideos } from "../../drizzle/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import { storagePut } from "../storage";
import { decryptText, encryptText } from "../encryption";

export const communityRouter = router({
  listPosts: publicProcedure
    .input(z.object({ category: z.string().optional() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return [];

        const conditions = [];
        if (input.category && input.category !== "todos") {
          conditions.push(eq(communityPosts.category, input.category as any));
        }

        const rawPosts = await db
          .select()
          .from(communityPosts)
          .where(conditions.length > 0 ? and(...conditions) : undefined)
          .orderBy(desc(communityPosts.createdAt));

        return rawPosts.map(p => ({
          ...p,
          authorName: p.isAnonymous ? "Anônimo Lumina" : (p.authorName || "Membro Lumina"),
        }));
      } catch (err) {
        console.error("Error listing posts:", err);
        return [];
      }
    }),

  createPost: protectedProcedure
    .input(
      z.object({
        title: z.string().min(3),
        content: z.string().min(5),
        category: z.enum(["desabafos", "conquistas", "reflexoes", "conselhos", "gratidao"]),
        isAnonymous: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const lowerContent = (input.title + " " + input.content).toLowerCase();
      const suicideKeywords = ["suicidio", "suicídio", "morrer", "acabar com tudo", "sumir", "nao aguento mais viver", "autoagressao", "cortar"];
      const riskFlagged = suicideKeywords.some(kw => lowerContent.includes(kw));

      const [newPost] = await db.insert(communityPosts).values({
        userId: ctx.user.id,
        authorName: ctx.user.name || "Membro Lumina",
        title: input.title,
        content: input.content,
        category: input.category,
        isAnonymous: input.isAnonymous,
        likesCount: 0,
        commentsCount: 0,
      });

      return { success: true, riskFlagged };
    }),

  likePost: protectedProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [existing] = await db
        .select()
        .from(communityLikes)
        .where(and(eq(communityLikes.postId, input.postId), eq(communityLikes.userId, ctx.user.id)));

      if (existing) {
        await db
          .delete(communityLikes)
          .where(and(eq(communityLikes.postId, input.postId), eq(communityLikes.userId, ctx.user.id)));

        await db
          .update(communityPosts)
          .set({ likesCount: sql`GREATEST(0, likesCount - 1)` })
          .where(eq(communityPosts.id, input.postId));

        return { liked: false };
      } else {
        await db.insert(communityLikes).values({
          postId: input.postId,
          userId: ctx.user.id,
        });

        await db
          .update(communityPosts)
          .set({ likesCount: sql`likesCount + 1` })
          .where(eq(communityPosts.id, input.postId));

        return { liked: true };
      }
    }),

  listComments: publicProcedure
    .input(z.object({ postId: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return [];

        const comments = await db
          .select()
          .from(communityComments)
          .where(eq(communityComments.postId, input.postId))
          .orderBy(communityComments.createdAt);

        return comments.map(c => ({
          ...c,
          authorName: c.isAnonymous ? "Anônimo Lumina" : (c.authorName || "Membro Lumina"),
        }));
      } catch (err) {
        return [];
      }
    }),

  createComment: protectedProcedure
    .input(
      z.object({
        postId: z.number(),
        content: z.string().min(2),
        isAnonymous: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(communityComments).values({
        postId: input.postId,
        userId: ctx.user.id,
        authorName: ctx.user.name || "Membro Lumina",
        content: input.content,
        isAnonymous: input.isAnonymous,
      });

      await db
        .update(communityPosts)
        .set({ commentsCount: sql`commentsCount + 1` })
        .where(eq(communityPosts.id, input.postId));

      return { success: true };
    }),

  reportPost: protectedProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(communityReports).values({
        postId: input.postId,
        userId: ctx.user.id,
        reason: "Conteúdo reportado pela comunidade",
      });

      return { success: true };
    }),

  /** Chat coletivo protegido: somente membros autenticados podem ler e enviar mensagens. */
  listChatMessages: protectedProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) return [];

      const rows = await db
        .select()
        .from(communityMessages)
        .orderBy(desc(communityMessages.createdAt), desc(communityMessages.id))
        .limit(60);

      return rows.reverse().map(message => ({
        ...message,
        content: decryptText(message.content),
        authorName: message.isAnonymous ? "Anônimo Lumina" : (message.authorName || "Membro Lumina"),
      }));
    } catch (err) {
      console.error("Error listing community chat messages:", err);
      return [];
    }
  }),

  sendChatMessage: protectedProcedure
    .input(z.object({ content: z.string().trim().min(1).max(500), isAnonymous: z.boolean().default(true) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const content = input.content.trim();
      const lowerContent = content.toLowerCase();
      const riskKeywords = ["suicidio", "suicídio", "me matar", "morrer", "acabar com tudo", "sumir", "não aguento mais viver", "nao aguento mais viver", "autoagressão", "autoagressao", "cortar"];
      const riskFlagged = riskKeywords.some(keyword => lowerContent.includes(keyword));

      const [result] = await db.insert(communityMessages).values({
        userId: ctx.user.id,
        authorName: ctx.user.name || "Membro Lumina",
        isAnonymous: input.isAnonymous,
        content: encryptText(content),
        riskFlagged,
      });

      return {
        success: true,
        riskFlagged,
        message: {
          id: result.insertId,
          userId: ctx.user.id,
          authorName: input.isAnonymous ? "Anônimo Lumina" : (ctx.user.name || "Membro Lumina"),
          isAnonymous: input.isAnonymous,
          content,
          riskFlagged,
          createdAt: new Date(),
        },
      };
    }),

  reportMessage: protectedProcedure
    .input(
      z.object({
        messageId: z.number(),
        reason: z.string().min(3),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(communityMessageReports).values({
        messageId: input.messageId,
        userId: ctx.user.id,
        reason: input.reason,
        status: "pending",
      });

      return { success: true };
    }),

  listMessageReports: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") {
      throw new Error("Unauthorized");
    }
    const db = await getDb();
    if (!db) return [];

    const rows = await db
      .select({
        reportId: communityMessageReports.id,
        messageId: communityMessageReports.messageId,
        reason: communityMessageReports.reason,
        status: communityMessageReports.status,
        reportedAt: communityMessageReports.createdAt,
        messageContent: communityMessages.content,
        messageAuthorName: communityMessages.authorName,
        messageAnonymous: communityMessages.isAnonymous,
        messageRiskFlagged: communityMessages.riskFlagged,
        messageCreatedAt: communityMessages.createdAt,
      })
      .from(communityMessageReports)
      .leftJoin(communityMessages, eq(communityMessageReports.messageId, communityMessages.id))
      .orderBy(desc(communityMessageReports.createdAt));

    return rows.map(row => ({
      ...row,
      messageContent: row.messageContent ? decryptText(row.messageContent) : "Mensagem removida",
      messageAuthorName: row.messageAnonymous ? "Anônimo Lumina" : (row.messageAuthorName || "Membro Lumina"),
    }));
  }),

  resolveMessageReport: protectedProcedure
    .input(z.object({ reportId: z.number(), status: z.enum(["resolved", "dismissed"]) }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(communityMessageReports)
        .set({ status: input.status })
        .where(eq(communityMessageReports.id, input.reportId));

      return { success: true };
    }),

  deleteChatMessage: protectedProcedure
    .input(z.object({ messageId: z.number(), reportId: z.number().optional() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.delete(communityMessages).where(eq(communityMessages.id, input.messageId));
      if (input.reportId) {
        await db
          .update(communityMessageReports)
          .set({ status: "resolved" })
          .where(eq(communityMessageReports.id, input.reportId));
      }
      return { success: true };
    }),

  uploadVideo: protectedProcedure
    .input(
      z.object({
        title: z.string().min(3),
        description: z.string().min(5),
        category: z.enum(["meditacao", "oracao", "motivacao"]),
        duration: z.string().default("5 min"),
        fileBase64: z.string(),
        fileName: z.string(),
        fileType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Extract base64 buffer
      const base64Data = input.fileBase64.replace(/^data:.*;base64,/, "");
      const buffer = Buffer.from(base64Data, "base64");
      const ext = input.fileName.split(".").pop() || "mp4";
      const key = `lumina-media-${Date.now()}-${Math.random().toString(36).substring(2, 8)}.${ext}`;

      const uploadResult = await storagePut(key, buffer, input.fileType);

      await db.insert(wellbeingVideos).values({
        title: input.title,
        description: input.description,
        youtubeId: uploadResult.url,
        category: input.category,
        duration: input.duration,
        featured: false,
      });

      return { success: true, url: uploadResult.url };
    }),

  listVideos: publicProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) return [];

      const videos = await db
        .select()
        .from(wellbeingVideos)
        .orderBy(desc(wellbeingVideos.createdAt));

      if (videos.length === 0) {
        const defaultVideos = [
          {
            title: "Meditação Guiada para Paz Interior e Alívio da Ansiedade",
            description: "Um momento de pausa com respiração consciente e palavras de acolhimento para acalmar o coração.",
            youtubeId: "86YLbkwjwqg",
            category: "meditacao",
            duration: "10 min",
            featured: true,
          },
          {
            title: "Palavra de Esperança: Renovando as Forças para o Amanhã",
            description: "Reflexão profunda sobre superação, fé e a certeza de que dias melhores estão por vir.",
            youtubeId: "5qap5aO4i9A",
            category: "oracao",
            duration: "7 min",
            featured: true,
          },
          {
            title: "Motivação Matinal: Comece o Dia com Gratidão e Propósito",
            description: "Afirmações diárias e pensamentos elevados para erguer o ânimo e encarar os desafios com coragem.",
            youtubeId: "ZXsQAXx_ao0",
            category: "motivacao",
            duration: "5 min",
            featured: false,
          },
        ];

        for (const v of defaultVideos) {
          await db.insert(wellbeingVideos).values(v);
        }
        return await db.select().from(wellbeingVideos).orderBy(desc(wellbeingVideos.createdAt));
      }
      return videos;
    } catch (err) {
      return [];
    }
  }),
});
