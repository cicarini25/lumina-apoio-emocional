import { describe, expect, it } from "vitest";
import { buildPresenceEmail } from "./presenceEmail";

describe("Lumina presence confirmation email", () => {
  it("builds a localized confirmation email without exposing provider secrets", () => {
    const email = buildPresenceEmail({
      code: "123456",
      recipient: "user@example.com",
      appUrl: "https://lumina.example.com",
    });

    expect(email.to).toEqual(["user@example.com"]);
    expect(email.subject).toContain("Confirme sua presença");
    expect(email.html).toContain("123456");
    expect(email.html).toContain("Lumina");
    expect(email.html).not.toContain("RESEND_API_KEY");
    expect(email.html).not.toContain("re_");
  });
});
