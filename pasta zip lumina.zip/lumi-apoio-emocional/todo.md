# Projeto TODO — Lumi (Apoio Emocional)

## Backend
- [x] Schema do banco: tabelas conversations, messages, userSettings (prompt de personalidade configurável)
- [x] Helpers de banco em server/db.ts (CRUD de conversas, mensagens, settings)
- [x] Router de chat: enviar mensagem, obter resposta empática da LLM com persona Lumi
- [x] Prompt de sistema da Lumi (empático, acolhedor, PT-BR) com personalização por usuário
- [x] Temas de conversa: Saúde Emocional, Relacionamentos, Trabalho, Apoio Espiritual
- [x] Detecção de conteúdo de risco (autoagressão/suicídio) na conversa → flag para exibir CVV
- [x] Histórico de conversas persistido por usuário (listar, retomar, excluir)
- [x] Router de settings: ler/salvar prompt de personalidade customizado

## Frontend
- [x] Tema visual: mesh gradient vibrante (rosa forte, violeta, laranja suave, azul profundo), tipografia grande/branca com sombra, subtítulo com letter-spacing amplo
- [x] Landing page acolhedora com CTA de login e apresentação da Lumi
- [x] Página de chat com a Lumi (mensagens, streaming/loading, markdown)
- [x] Seletor de tema de conversa ao iniciar nova conversa
- [x] Sidebar/lista de histórico de conversas do usuário
- [x] Exercício de respiração guiada integrado ao chat (animação de respiração)
- [x] Afirmações diárias integradas ao chat
- [x] Banner/alerta CVV (188 / cvv.org.br) exibido quando risco detectado
- [x] Página/modal de configuração da persona (prompt personalizável)
- [x] Layout responsivo mobile e desktop
- [x] Aviso de clareza de papel (assistente virtual, não substitui psicólogo/psiquiatra)

## Qualidade
- [x] Testes vitest para detecção de risco, prompt da persona e afirmações
- [x] Verificação visual (desktop e mobile)
- [x] Testes vitest para routers (chat.send, conversations, settings)
- [x] Checkpoint final e entrega

## Ajustes solicitados pelo usuário
- [x] Renomear assistente de "Lumi" para "Lumina" em todo o app (landing, chat, persona, título, testes)
- [x] Aplicar slogan "Uma luz para ouvir, acolher e caminhar ao seu lado" na landing page

## Notas de escopo
- Restrição do usuário: CVV "só deve ser ativado quando conteúdo de risco for detectado" → interpretada como o alerta/banner de crise condicional; o aviso legal discreto de rodapé (clareza de papel) é mantido por responsabilidade ética, mas pode ser removido a pedido.
- Streaming de resposta: chat usa loading indicator com resposta completa (sem SSE); pode ser evoluído para streaming se o usuário desejar.

## Exportação
- [x] Orientar exportação do projeto Lumina para o GitHub com nome de repositório e instrução sobre anexos
- [x] Confirmar ao usuário o procedimento de exportação pelo painel GitHub

## Ícone oficial da Lumina
- [x] Preparar versão quadrada do logo oficial para ícone de aplicativo, priorizando símbolo e estrela
- [x] Integrar ícone nos metadados instaláveis, favicon e atalhos do app
- [x] Verificar o visual e salvar checkpoint da atualização do ícone

## Ajustes de abertura e nome do app
- [x] Alterar o nome curto do app instalado para "Lumina Apoio Emocional"
- [x] Criar efeito pulsante no logotipo ao abrir a aplicação
- [x] Testar a abertura em mobile e desktop e salvar checkpoint da atualização

## Novo fluxo de abertura
- [x] Remover a primeira splash independente do fluxo inicial
- [x] Manter a página com a logo completa e as escritas abaixo como abertura principal
- [x] Aplicar animação pulsante de 7 segundos ao abrir a página principal
- [x] Validar o fluxo em mobile e desktop e salvar checkpoint da atualização

## Correção do fluxo em duas telas
- [x] Criar a primeira tela independente com a arte completa da Lumina e pulso de 7 segundos
- [x] Remover o cartão do logotipo da segunda página, mantendo apenas o conteúdo principal
- [x] Validar a transição entre s duas telas em mobile e desktop e salvar checkpoint

## Empacotamento Móvel (Google Play e App Store)
- [x] Inicializar e configurar Capacitor para Android e iOS (Android + iOS adicionados com sucesso)
- [x] Ajustar capacitor.config.ts com nome "Lumina Apoio Emocional" e bundle ID (com.lumiapp.apoioemocional)
- [x] Integrar ícones de 512x512 e splash screens nas estruturas nativas Android e iOS
- [x] Compilar assets web e sincronizar plataformas móveis (Android/iOS validados)
- [x] Criar guia de submissão e checklist para Google Play Console e App Store Connect

## Domínio Próprio
- [x] Elaborar o guia completo de domínio próprio (custom-domain-guide.md)

## Autenticação Profissional Própria (Lumina Auth)
- [x] Criar tabelas de usuários locais, senhas hasheadas e provedores no Drizzle schema
- [x] Implementar rotas tRPC para login por e-mail/senha, cadastro e recuperação
- [x] Desenvolver a interface visual de login/cadastro da Lumina (sem menção ao Manus)
- [x] Integrar botões para Google, Apple, Facebook e biometria/passkeys
- [x] Testar fluxos de autenticação e salvar checkpoint final

## Verificação 2FA por SMS/E-mail e Criptografia
- [x] Adicionar campos de telefone e códigos de verificação (SMS e e-mail) no banco de dados
- [x] Implementar rotas tRPC para envio e validação obrigatória de código 2FA antes de liberar o app
- [x] Criar rotina de criptografia de mensagens e dados sensíveis dos usuários
- [x] Atualizar o AuthModal para incluir a etapa de verificação por código SMS/E-mail
- [x] Validar a segurança e integridade do app com testes automatizados e checkpoint

## Confirmação de presença e identidade da Lumina
- [x] Substituir chamadas restantes de startLogin pelo fluxo próprio AuthModal da Lumina
- [x] Criar confirmação de presença por e-mail ou notificação após login Google
- [x] Bloquear acesso ao app até a confirmação da presença
- [x] Remover referências visuais à marca externa da experiência de autenticação
- [x] Testar login Google, confirmação, bloqueio e rotas protegidas

- [x] Configurar um Client ID oficial do Google para substituir o login social simulado
- [x] Validar no servidor o token de identidade Google antes de criar sessão Lumina

## Cobertura complementar da autenticação Google
- [x] Adicionar testes de login Google com token válido e inválido, estado pendente e sessão emitida somente após confirmação
- [x] Testar bloqueio de rotas protegidas antes da confirmação e liberação após validar o código
- [x] Executar validação explícita do formato de `VITE_GOOGLE_CLIENT_ID` e do comportamento quando ausente ou inválido

## Proteção de dados — revisão final
- [x] Configurar `LUMINA_ENCRYPTION_KEY` como segredo do ambiente sem hardcode
- [x] Substituir a criptografia antiga por AES-256-GCM autenticada
- [x] Criptografar mensagens e prompts sensíveis na persistência e descriptografar apenas no servidor
- [x] Validar a chave com teste Vitest de ciclo criptográfico
- [ ] Integrar provedor transacional de SMS para envio real ao telefone; atualmente a confirmação em produção está ligada ao e-mail verificado

## Nova Funcionalidade: Comunidade de Apoio e Vídeos de Bem-Estar
- [x] Modelar tabelas Drizzle para Posts da Comunidade, Comentários, Reações, Denúncias e Biblioteca de Vídeos
- [x] Criar rotas tRPC para criar posts, listar feed filtrado por categorias (Desabafos, Conquistas, Reflexões), comentar e reagir
- [x] Criar rotina de curadoria e moderação de conteúdo (alerta automático e botão de denúncia)
- [x] Desenvolver a interface visual da Comunidade (estilo feed acolhedor com perfis anônimos opcionais)
- [x] Desenvolver a galeria de vídeos de bem-estar, oração e motivação (estilo YouTube embutido, categorizados)
- [x] Integrar novas abas e rotas na navegação principal da Lumina
- [x] Testar e validar a nova experiência com Vitest e checkpoint publicado
- [x] Corrigir erro de envio do código de confirmação no login/cadastro da Lumina e validar credenciais do Resend via testes automatizados
- [x] Remover dependência de SMS na autenticação da Lumina, renomeando o botão de login para "Entrar" e permitindo acesso direto sem exigir gateway externo de e-mail/SMS
- [x] Corrigir o ciclo de redirecionamento no login da Lumina (impedir que o modal reabra após o login bem-sucedido e estabilizar a sessão no useAuth)
- [x] Corrigir o erro ao iniciar conversas pelos temas na tela de conversas (garantir inserção correta no banco e título/resposta inicial no chat)

## Chat Comunitário de Interação
- [x] Modelar tabela segura `communityMessages` com conteúdo criptografado, autoria privada e anonimato opcional
- [x] Criar procedures protegidas para listar e enviar mensagens com limite de 500 caracteres e sinalização de risco
- [x] Integrar a seção **Chat Interativo** na sala Comunidade com polling periódico e layout responsivo
- [x] Preservar a separação entre identidade privada para moderação e nome público exibido na sala
- [x] Validar TypeScript, suíte Vitest e captura visual da Comunidade em mobile e desktop
- [x] Adicionar denúncia individual de mensagens do chat e painel administrativo de moderação
- [ ] Avaliar WebSocket/SSE, paginação, rate limiting e salas temáticas em uma próxima fase
- [ ] Revisar acessibilidade, retenção de mensagens e política de privacidade específica do chat

### Decisões de produto — Chat Comunitário
- [x] Começar com uma sala pública única, sem conversas privadas entre usuários
- [x] Usar anonimato opcional por mensagem, mantendo a identidade privada no servidor
- [x] Atualizar automaticamente por polling nesta primeira versão
- [x] Restringir envio e leitura do chat a usuários autenticados
- [x] Exibir orientação do CVV 188 quando uma mensagem for sinalizada como risco
- [ ] Evoluir moderação, notificações e tempo real após observar o uso da comunidade
- [x] Corrigir alinhamento e largura dos botões de abas na página Comunidade (`Community.tsx`) para evitar que textos transbordem em telas móveis
- [x] Diagnosticar e solucionar a falha de conexão/exportação para o GitHub, fornecendo o método alternativo seguro via ZIP e guia de inicialização do repositório
- [x] Diagnosticar a falha de conexão com o GitHub identificando a etapa exata que quebra (autorização, popup, painel ou download) e registrar a causa confirmada
- [x] Gerar e validar um pacote ZIP limpo/exportável do projeto Lumina, confirmando que o código pode ser baixado sem segredos
- [x] Validar o fluxo alternativo de envio ao GitHub com instruções testadas (repositório novo, push/manual import) e então atualizar o roadmap
