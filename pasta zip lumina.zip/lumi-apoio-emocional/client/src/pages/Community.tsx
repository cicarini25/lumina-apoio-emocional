import React, { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { AuthModal } from "@/components/AuthModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Heart, MessageCircle, Share2, PlusCircle, ShieldAlert, Sparkles, 
  Video, BookOpen, Send, Lock, ArrowLeft, CheckCircle2, AlertCircle, Flag, Upload, Music, Trash2, X 
} from "lucide-react";
import { Link } from "wouter";

export function Community() {
  const { user } = useAuth();
  const [authOpen, setAuthOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("comunidade");
  const [selectedCategory, setSelectedCategory] = useState("todos");
  const [newPostOpen, setNewPostOpen] = useState(false);
  const [uploadVideoOpen, setUploadVideoOpen] = useState(false);
  const [chatContent, setChatContent] = useState("");
  const [chatAnonymous, setChatAnonymous] = useState(true);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  
  // Form state for new post
  const [postTitle, setPostTitle] = useState("");
  const [postContent, setPostContent] = useState("");
  const [postCategory, setPostCategory] = useState<"desabafos" | "conquistas" | "reflexoes" | "conselhos" | "gratidao">("desabafos");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [postSuccessMessage, setPostSuccessMessage] = useState("");

  // Upload video/audio state
  const [mediaTitle, setMediaTitle] = useState("");
  const [mediaDesc, setMediaDesc] = useState("");
  const [mediaCategory, setMediaCategory] = useState<"meditacao" | "oracao" | "motivacao">("meditacao");
  const [mediaDuration, setMediaDuration] = useState("5 min");
  const [mediaFileBase64, setMediaFileBase64] = useState("");
  const [mediaFileName, setMediaFileName] = useState("");
  const [mediaFileType, setMediaFileType] = useState("video/mp4");
  const [uploadSuccess, setUploadSuccess] = useState("");

  // Comment state per post
  const [commentInputs, setCommentInputs] = useState<Record<number, string>>({});
  const [expandedPostId, setExpandedPostId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: posts = [], isLoading: postsLoading } = trpc.community.listPosts.useQuery({ category: selectedCategory });
  const { data: videos = [], isLoading: videosLoading } = trpc.community.listVideos.useQuery();
  const { data: chatMessages = [], isLoading: chatLoading } = trpc.community.listChatMessages.useQuery(undefined, {
    enabled: Boolean(user) && activeTab === "chat",
    refetchInterval: Boolean(user) && activeTab === "chat" ? 6000 : false,
  });
  const { data: messageReports = [], isLoading: reportsLoading } = trpc.community.listMessageReports.useQuery(undefined, {
    enabled: user?.role === "admin",
    refetchInterval: user?.role === "admin" ? 15000 : false,
  });

  const createPostMutation = trpc.community.createPost.useMutation({
    onSuccess: (data) => {
      setPostSuccessMessage(
        data.riskFlagged 
          ? "Sua partilha foi publicada, mas detectamos que você pode estar passando por um momento difícil. Lembre-se que o CVV (188) está sempre disponível para acolher você."
          : "Sua partilha foi publicada com carinho na comunidade!"
      );
      setPostTitle("");
      setPostContent("");
      utils.community.listPosts.invalidate();
      setTimeout(() => {
        setNewPostOpen(false);
        setPostSuccessMessage("");
      }, 3500);
    },
  });

  const uploadVideoMutation = trpc.community.uploadVideo.useMutation({
    onSuccess: () => {
      setUploadSuccess("Mídia importada e publicada com sucesso na biblioteca de bem-estar!");
      setMediaTitle("");
      setMediaDesc("");
      setMediaFileBase64("");
      setMediaFileName("");
      utils.community.listVideos.invalidate();
      setTimeout(() => {
        setUploadVideoOpen(false);
        setUploadSuccess("");
      }, 3000);
    },
  });

  const likeMutation = trpc.community.likePost.useMutation({
    onSuccess: () => {
      utils.community.listPosts.invalidate();
    },
  });

  const createCommentMutation = trpc.community.createComment.useMutation({
    onSuccess: (_, variables) => {
      setCommentInputs(prev => ({ ...prev, [variables.postId]: "" }));
      utils.community.listPosts.invalidate();
    },
  });

  const sendChatMessageMutation = trpc.community.sendChatMessage.useMutation({
    onSuccess: (data) => {
      setChatContent("");
      utils.community.listChatMessages.invalidate();
      if (data.riskFlagged) {
        alert("Percebemos que você pode estar passando por um momento muito difícil. O CVV atende gratuitamente pelo 188.");
      }
    },
  });

  const reportMessageMutation = trpc.community.reportMessage.useMutation({
    onSuccess: () => {
      alert("Denúncia registrada com sucesso. Agradecemos por ajudar a manter a comunidade acolhedora.");
    },
  });

  const resolveMessageReportMutation = trpc.community.resolveMessageReport.useMutation({
    onSuccess: () => utils.community.listMessageReports.invalidate(),
  });

  const deleteChatMessageMutation = trpc.community.deleteChatMessage.useMutation({
    onSuccess: () => {
      utils.community.listMessageReports.invalidate();
      utils.community.listChatMessages.invalidate();
    },
  });

  useEffect(() => {
    const element = chatScrollRef.current;
    if (element) element.scrollTop = element.scrollHeight;
  }, [chatMessages.length, activeTab]);

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthOpen(true);
      return;
    }
    const content = chatContent.trim();
    if (!content || sendChatMessageMutation.isPending) return;
    sendChatMessageMutation.mutate({ content, isAnonymous: chatAnonymous });
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthOpen(true);
      return;
    }
    createPostMutation.mutate({
      title: postTitle,
      content: postContent,
      category: postCategory,
      isAnonymous,
    });
  };

  const handleLike = (postId: number) => {
    if (!user) {
      setAuthOpen(true);
      return;
    }
    likeMutation.mutate({ postId });
  };

  const handleAddComment = (postId: number, e: React.FormEvent) => {
    e.preventDefault();
    const content = commentInputs[postId];
    if (!content || content.trim().length < 2) return;
    if (!user) {
      setAuthOpen(true);
      return;
    }
    createCommentMutation.mutate({ postId, content, isAnonymous: false });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 50 * 1024 * 1024) {
      alert("O arquivo é muito grande. O limite máximo é de 50MB.");
      return;
    }

    setMediaFileName(file.name);
    setMediaFileType(file.type || "video/mp4");

    const reader = new FileReader();
    reader.onload = () => {
      setMediaFileBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthOpen(true);
      return;
    }
    if (!mediaFileBase64) {
      alert("Por favor, selecione um arquivo MP3 ou MP4.");
      return;
    }

    uploadVideoMutation.mutate({
      title: mediaTitle,
      description: mediaDesc,
      category: mediaCategory,
      duration: mediaDuration,
      fileBase64: mediaFileBase64,
      fileName: mediaFileName,
      fileType: mediaFileType,
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans pb-20">
      {/* HEADER */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-purple-500/20 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-purple-300 hover:text-white rounded-full p-2">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-base font-bold bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 bg-clip-text text-transparent">
                Comunidade & Biblioteca Lumina
              </h1>
              <p className="text-xs text-purple-200/60">Um espaço seguro para partilhar e acolher</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user ? (
              <Button
                onClick={() => setNewPostOpen(true)}
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium rounded-full text-xs h-9 px-4 shadow-lg shadow-purple-900/30 gap-1.5"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Nova Partilha</span>
              </Button>
            ) : (
              <Button
                onClick={() => setAuthOpen(true)}
                className="bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-full text-xs h-9 px-4"
              >
                Entrar
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="w-full max-w-2xl mx-auto grid grid-cols-3 gap-1 bg-slate-900/90 border border-purple-500/20 rounded-2xl p-1 overflow-hidden">
            <TabsTrigger 
              value="comunidade" 
              className="min-w-0 w-full justify-center text-center leading-tight whitespace-normal rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-600 data-[state=active]:text-white text-[11px] sm:text-xs font-medium px-2 py-2.5 h-auto min-h-10 text-purple-300"
            >
              <span className="block w-full text-center">Comunidade de Apoio</span>
            </TabsTrigger>
            <TabsTrigger 
              value="videos" 
              className="min-w-0 w-full justify-center text-center leading-tight whitespace-normal rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-600 data-[state=active]:text-white text-[11px] sm:text-xs font-medium px-2 py-2.5 h-auto min-h-10 text-purple-300"
            >
              <span className="block w-full text-center">Vídeos &amp; Músicas</span>
            </TabsTrigger>
            <TabsTrigger 
              value="chat" 
              className="min-w-0 w-full justify-center text-center leading-tight whitespace-normal rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-600 data-[state=active]:text-white text-[11px] sm:text-xs font-medium px-2 py-2.5 h-auto min-h-10 text-purple-300"
            >
              <span className="flex w-full items-center justify-center gap-1 text-center">
                <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                <span>Chat Interativo</span>
              </span>
            </TabsTrigger>
          </TabsList>

          {/* COMMUNITY TAB */}
          <TabsContent value="comunidade" className="space-y-6">
            {/* CATEGORY FILTER */}
            <div className="flex items-center justify-start gap-2 overflow-x-auto pb-2 px-1 scrollbar-none">
              {[
                { id: "todos", label: "Todas as Partilhas" },
                { id: "desabafos", label: "Desabafos" },
                { id: "conquistas", label: "Conquistas" },
                { id: "reflexoes", label: "Reflexões" },
                { id: "conselhos", label: "Conselhos" },
                { id: "gratidao", label: "Gratidão" },
              ].map(cat => (
                <Button
                  key={cat.id}
                  variant={selectedCategory === cat.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(cat.id)}
                    className={`shrink-0 rounded-full text-xs h-8 px-4 whitespace-nowrap transition-all ${
                    selectedCategory === cat.id
                      ? "bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-900/40"
                      : "bg-slate-900/80 text-purple-300 border-purple-500/20 hover:bg-purple-900/40 hover:text-white"
                  }`}
                >
                  {cat.label}
                </Button>
              ))}
            </div>

            {/* POSTS FEED */}
            {postsLoading ? (
              <div className="text-center py-20 text-purple-300 animate-pulse">
                Carregando partilhas com carinho...
              </div>
            ) : posts.length === 0 ? (
              <Card className="bg-slate-900/60 border-purple-500/20 rounded-3xl p-8 text-center space-y-4">
                <CardContent className="space-y-3 pt-4">
                  <div className="w-16 h-16 bg-purple-900/40 rounded-full flex items-center justify-center mx-auto text-pink-400">
                    <Heart className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">Nenhuma partilha nesta categoria ainda</h3>
                  <p className="text-sm text-purple-200/70 max-w-md mx-auto">
                    Seja o primeiro a compartilhar uma palavra de conforto, um desabafo ou uma reflexão para inspirar quem está caminhando ao seu lado.
                  </p>
                  <Button 
                    onClick={() => {
                      if (!user) setAuthOpen(true);
                      else setNewPostOpen(true);
                    }}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full mt-2"
                  >
                    Fazer a primeira partilha
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {posts.map(post => (
                  <Card key={post.id} className="bg-slate-900/80 border-purple-500/20 shadow-xl rounded-3xl overflow-hidden hover:border-purple-500/40 transition-all">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center font-bold text-sm text-white shadow-inner">
                            {post.authorName.charAt(0)}
                          </div>
                          <div>
                            <span className="text-sm font-semibold text-white">{post.authorName}</span>
                            <span className="text-xs text-purple-300/60 block">
                              {new Date(post.createdAt).toLocaleDateString("pt-BR", { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                        <Badge variant="outline" className="border-purple-500/30 text-purple-300 bg-purple-950/40 capitalize text-xs">
                          {post.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2 pb-3">
                      <h3 className="text-base font-bold text-pink-200">{post.title}</h3>
                      <p className="text-sm text-purple-100/90 whitespace-pre-wrap leading-relaxed">{post.content}</p>
                    </CardContent>
                    <CardFooter className="pt-2 pb-4 border-t border-purple-500/10 flex items-center justify-between bg-slate-950/30">
                      <div className="flex items-center gap-4">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleLike(post.id)}
                          className="text-pink-400 hover:text-pink-300 hover:bg-pink-950/30 rounded-full h-8 px-3 text-xs gap-1.5"
                        >
                          <Heart className="w-4 h-4 fill-current" />
                          <span>{post.likesCount} Apoios</span>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => setExpandedPostId(expandedPostId === post.id ? null : post.id)}
                          className="text-purple-300 hover:text-white hover:bg-purple-950/30 rounded-full h-8 px-3 text-xs gap-1.5"
                        >
                          <MessageCircle className="w-4 h-4" />
                          <span>{post.commentsCount} Comentários</span>
                        </Button>
                      </div>
                      <ReportButton postId={post.id} user={user} setAuthOpen={setAuthOpen} />
                    </CardFooter>

                    {/* Comments Section */}
                    {expandedPostId === post.id && (
                      <CommentSection postId={post.id} user={user} setAuthOpen={setAuthOpen} />
                    )}
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* INTERACTIVE CHAT TAB */}
          <TabsContent value="chat" className="space-y-5">
            {!user ? (
              <Card className="bg-gradient-to-br from-purple-950/80 via-slate-900/90 to-pink-950/60 border-purple-500/30 rounded-3xl shadow-xl overflow-hidden">
                <CardContent className="py-12 px-6 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-br from-pink-500/20 to-purple-500/30 flex items-center justify-center text-pink-300">
                    <Lock className="w-8 h-8" />
                  </div>
                  <div className="space-y-2">
                    <h2 className="text-xl font-bold text-white">Entre para participar do bate-papo</h2>
                    <p className="text-sm text-purple-200/75 max-w-md mx-auto leading-relaxed">
                      O Chat Interativo é reservado aos membros autenticados para proteger a privacidade e manter um ambiente acolhedor.
                    </p>
                  </div>
                  <Button
                    onClick={() => setAuthOpen(true)}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full px-6"
                  >
                    Entrar na Lumina
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card className="bg-gradient-to-r from-purple-900/50 via-indigo-900/40 to-pink-900/40 border-purple-500/30 rounded-3xl shadow-xl overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 bg-pink-500/20 rounded-2xl text-pink-300">
                          <MessageCircle className="w-6 h-6" />
                        </div>
                        <div>
                          <CardTitle className="text-lg text-white">Bate-papo Lumina</CardTitle>
                          <p className="text-xs text-purple-200/75 mt-1 leading-relaxed">
                            Converse com outros membros com respeito, acolhimento e liberdade para usar o anonimato.
                          </p>
                        </div>
                      </div>
                      <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-400/20 whitespace-nowrap text-[10px]">
                        Ambiente protegido
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div ref={chatScrollRef} className="h-[min(52vh,30rem)] min-h-72 overflow-y-auto rounded-2xl border border-purple-500/15 bg-slate-950/45 p-3 sm:p-4 space-y-3">
                      {chatLoading ? (
                        <div className="h-full min-h-64 flex items-center justify-center text-sm text-purple-300 animate-pulse">
                          Carregando as conversas com carinho...
                        </div>
                      ) : chatMessages.length === 0 ? (
                        <div className="h-full min-h-64 flex flex-col items-center justify-center text-center px-5 space-y-3">
                          <div className="w-12 h-12 rounded-full bg-purple-500/15 flex items-center justify-center text-purple-300">
                            <Sparkles className="w-6 h-6" />
                          </div>
                          <p className="text-sm font-medium text-purple-100">O bate-papo está começando agora.</p>
                          <p className="text-xs text-purple-200/65 max-w-xs">Seja a primeira pessoa a deixar uma palavra de acolhimento para quem chegar.</p>
                        </div>
                      ) : (
                        chatMessages.map(message => {
                          const isOwnMessage = message.userId === user.id;
                          return (
                            <div key={message.id} className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}>
                              <div className={`max-w-[88%] sm:max-w-[76%] rounded-2xl px-3.5 py-2.5 shadow-sm ${isOwnMessage ? "bg-gradient-to-br from-pink-500 to-purple-600 text-white rounded-br-md" : "bg-slate-800/90 border border-purple-500/15 text-purple-50 rounded-bl-md"}`}>
                                <div className="flex items-center justify-between gap-3 mb-1">
                                  <span className={`text-[10px] font-semibold ${isOwnMessage ? "text-white/85" : "text-pink-200"}`}>
                                    {isOwnMessage ? (message.isAnonymous ? "Você · anônimo" : "Você") : message.authorName}
                                  </span>
                                  <span className={`text-[9px] ${isOwnMessage ? "text-white/65" : "text-purple-300/55"}`}>
                                    {new Date(message.createdAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                                  </span>
                                </div>
                                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>
                                <div className="flex items-center justify-end gap-2 mt-1.5 pt-1 border-t border-white/10">
                                  {message.riskFlagged && (
                                    <span className="text-[9px] bg-amber-500/20 text-amber-200 px-1.5 py-0.5 rounded">
                                      Apoio 188
                                    </span>
                                  )}
                                  <button
                                    onClick={() => {
                                      const reason = window.prompt("Motivo da denúncia (ex: conteúdo ofensivo, spam):");
                                      if (reason && reason.trim()) {
                                        reportMessageMutation.mutate({ messageId: message.id, reason: reason.trim() });
                                      }
                                    }}
                                    className="text-[9px] text-white/50 hover:text-white/90 underline transition"
                                  >
                                    Denunciar
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    <form onSubmit={handleSendChatMessage} className="mt-4 space-y-3">
                      <div className="flex items-end gap-2">
                        <Textarea
                          value={chatContent}
                          onChange={(event) => setChatContent(event.target.value.slice(0, 500))}
                          placeholder="Escreva uma mensagem de apoio..."
                          maxLength={500}
                          rows={2}
                          className="resize-none bg-slate-950/60 border-purple-500/25 text-white placeholder:text-purple-300/45 rounded-2xl focus-visible:ring-pink-500/50"
                          aria-label="Mensagem do chat comunitário"
                        />
                        <Button
                          type="submit"
                          disabled={!chatContent.trim() || sendChatMessageMutation.isPending}
                          className="h-11 w-11 shrink-0 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white p-0 disabled:opacity-50"
                          aria-label="Enviar mensagem"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <label className="inline-flex items-center gap-2 text-xs text-purple-200/75 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={chatAnonymous}
                            onChange={(event) => setChatAnonymous(event.target.checked)}
                            className="h-4 w-4 rounded border-purple-500/40 bg-slate-900 accent-pink-500"
                          />
                          Enviar como anônimo
                        </label>
                        <span className="text-[10px] text-purple-300/50">{chatContent.length}/500 · atualização automática</span>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <div className="flex items-start gap-2 rounded-2xl border border-emerald-400/15 bg-emerald-500/5 px-4 py-3 text-xs text-emerald-100/75">
                  <ShieldAlert className="w-4 h-4 shrink-0 text-emerald-300 mt-0.5" />
                  <p>Cuide de você e das outras pessoas. Em uma emergência ou risco imediato, procure ajuda local; no Brasil, o CVV atende pelo 188.</p>
                </div>
              </>
            )}
          </TabsContent>

          {/* VIDEOS TAB */}
          <TabsContent value="videos" className="space-y-6">
            <div className="bg-gradient-to-r from-purple-900/40 via-indigo-900/40 to-pink-900/40 border border-purple-500/30 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-pink-500/20 rounded-2xl text-pink-400">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Biblioteca de Bem-Estar & Oração</h2>
                  <p className="text-xs text-purple-200/80">Assista vídeos recomendados ou importe seus próprios arquivos MP3/MP4.</p>
                </div>
              </div>
              <Button
                onClick={() => {
                  if (!user) setAuthOpen(true);
                  else setUploadVideoOpen(true);
                }}
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full text-xs h-10 px-5 gap-2 shadow-lg shrink-0"
              >
                <Upload className="w-4 h-4" />
                <span>Importar Vídeo / Áudio</span>
              </Button>
            </div>

            {videosLoading ? (
              <div className="text-center py-16 text-purple-300 animate-pulse">
                Carregando biblioteca de bem-estar...
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {videos.map(video => {
                  const isUploaded = video.youtubeId.startsWith("http");
                  return (
                    <Card key={video.id} className="bg-slate-900/80 border-purple-500/20 shadow-xl rounded-3xl overflow-hidden flex flex-col justify-between hover:border-purple-500/40 transition-all">
                      <div>
                        {/* Media Player Container */}
                        <div className="relative w-full aspect-video bg-slate-950 flex items-center justify-center">
                          {isUploaded ? (
                            video.youtubeId.includes(".mp3") || video.youtubeId.includes("audio") ? (
                              <div className="flex flex-col items-center justify-center p-6 text-center space-y-3 w-full h-full bg-gradient-to-b from-purple-950/60 to-slate-950">
                                <div className="w-14 h-14 bg-pink-500/20 rounded-full flex items-center justify-center text-pink-400">
                                  <Music className="w-7 h-7" />
                                </div>
                                <audio controls className="w-full max-w-xs">
                                  <source src={video.youtubeId} />
                                  Seu navegador não suporta áudio.
                                </audio>
                              </div>
                            ) : (
                              <video controls className="w-full h-full object-cover">
                                <source src={video.youtubeId} />
                                Seu navegador não suporta vídeo.
                              </video>
                            )
                          ) : (
                            <iframe
                              src={`https://www.youtube.com/embed/${video.youtubeId}`}
                              title={video.title}
                              className="w-full h-full absolute inset-0 border-0"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            />
                          )}
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between mb-1">
                            <Badge variant="outline" className="border-pink-500/30 text-pink-300 bg-pink-950/30 capitalize text-xs">
                              {video.category}
                            </Badge>
                            <span className="text-xs text-purple-300/60 font-medium">{video.duration}</span>
                          </div>
                          <CardTitle className="text-base font-bold text-white leading-snug">{video.title}</CardTitle>
                        </CardHeader>
                      </div>
                      <CardContent className="pt-0 pb-4">
                        <p className="text-xs text-purple-200/70 leading-relaxed">{video.description}</p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {user?.role === "admin" && (
        <section className="max-w-4xl mx-auto px-4 pb-8" aria-labelledby="moderation-title">
          <Card className="bg-amber-950/20 border-amber-400/25 rounded-3xl overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-2xl bg-amber-400/10 text-amber-200">
                    <ShieldAlert className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <CardTitle id="moderation-title" className="text-base text-amber-100">Moderação do Chat</CardTitle>
                    <p className="text-xs text-amber-100/65 mt-1">Denúncias são visíveis somente para administradores.</p>
                  </div>
                </div>
                <Badge className="w-fit bg-amber-400/10 text-amber-200 border border-amber-300/20">
                  {messageReports.filter(report => report.status === "pending").length} pendentes
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {reportsLoading ? (
                <p className="py-5 text-sm text-amber-100/65">Carregando denúncias...</p>
              ) : messageReports.filter(report => report.status === "pending").length === 0 ? (
                <div className="rounded-2xl border border-emerald-300/15 bg-emerald-400/5 px-4 py-5 text-sm text-emerald-100/75">
                  Nenhuma denúncia pendente no momento.
                </div>
              ) : (
                <div className="space-y-3">
                  {messageReports.filter(report => report.status === "pending").map(report => (
                    <article key={report.reportId} className="rounded-2xl border border-amber-300/15 bg-slate-950/45 p-4 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-amber-100/60">
                        <span>{report.messageAuthorName} · mensagem #{report.messageId}</span>
                        <time dateTime={new Date(report.reportedAt).toISOString()}>{new Date(report.reportedAt).toLocaleString("pt-BR")}</time>
                      </div>
                      <p className="text-sm leading-relaxed text-white whitespace-pre-wrap break-words">{report.messageContent}</p>
                      <p className="text-xs text-amber-100/70">Motivo: {report.reason}</p>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={resolveMessageReportMutation.isPending || deleteChatMessageMutation.isPending}
                          onClick={() => resolveMessageReportMutation.mutate({ reportId: report.reportId, status: "dismissed" })}
                          className="rounded-full border-slate-500/40 bg-transparent text-slate-200 hover:bg-slate-800"
                        >
                          <X className="w-3.5 h-3.5 mr-1.5" aria-hidden="true" /> Dispensar
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={resolveMessageReportMutation.isPending || deleteChatMessageMutation.isPending}
                          onClick={() => resolveMessageReportMutation.mutate({ reportId: report.reportId, status: "resolved" })}
                          className="rounded-full border-emerald-400/30 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" aria-hidden="true" /> Resolver
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={resolveMessageReportMutation.isPending || deleteChatMessageMutation.isPending}
                          onClick={() => deleteChatMessageMutation.mutate({ messageId: report.messageId, reportId: report.reportId })}
                          className="rounded-full border-red-400/30 bg-red-500/10 text-red-200 hover:bg-red-500/20"
                        >
                          <Trash2 className="w-3.5 h-3.5 mr-1.5" aria-hidden="true" /> Remover mensagem
                        </Button>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      )}

      {/* NEW POST DIALOG */}
      <Dialog open={newPostOpen} onOpenChange={setNewPostOpen}>
        <DialogContent className="bg-slate-950 border border-purple-500/30 text-white rounded-3xl max-w-lg mx-auto p-6">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent flex items-center gap-2">
              <Heart className="w-5 h-5 text-pink-400" />
              Criar Partilha na Comunidade
            </DialogTitle>
          </DialogHeader>

          {postSuccessMessage ? (
            <div className="bg-purple-950/80 border border-purple-500/40 rounded-2xl p-6 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto" />
              <p className="text-sm font-medium text-purple-100">{postSuccessMessage}</p>
            </div>
          ) : (
            <form onSubmit={handleCreatePost} className="space-y-4 pt-2">
              <div>
                <label className="text-xs font-medium text-purple-200 mb-1.5 block">Categoria</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: "desabafos", label: "Desabafo" },
                    { id: "conquistas", label: "Conquista" },
                    { id: "reflexoes", label: "Reflexão" },
                    { id: "conselhos", label: "Conselho" },
                    { id: "gratidao", label: "Gratidão" },
                  ].map(cat => (
                    <Button
                      key={cat.id}
                      type="button"
                      variant={postCategory === cat.id ? "default" : "outline"}
                      onClick={() => setPostCategory(cat.id as any)}
                      className={`text-xs rounded-xl h-9 capitalize ${
                        postCategory === cat.id 
                          ? "bg-purple-600 text-white border-purple-500" 
                          : "bg-slate-900 text-purple-300 border-purple-500/20 hover:bg-purple-900/40"
                      }`}
                    >
                      {cat.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Título da partilha</label>
                <Input
                  value={postTitle}
                  onChange={e => setPostTitle(e.target.value)}
                  placeholder="Ex: Como consegui respirar nos momentos difíceis..."
                  className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Sua mensagem ou reflexão</label>
                <Textarea
                  value={postContent}
                  onChange={e => setPostContent(e.target.value)}
                  placeholder="Escreva com o coração aberto. Aqui é um espaço seguro e sem julgamentos..."
                  className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 rounded-xl min-h-[120px]"
                  required
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-purple-200">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={e => setIsAnonymous(e.target.checked)}
                    className="rounded border-purple-500 bg-slate-900 text-purple-600 focus:ring-purple-500 w-4 h-4"
                  />
                  <span>Publicar como Anônimo</span>
                </label>

                <Button
                  type="submit"
                  disabled={createPostMutation.isPending}
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium rounded-xl px-6"
                >
                  {createPostMutation.isPending ? "Publicando..." : "Compartilhar"}
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* UPLOAD MEDIA DIALOG */}
      <Dialog open={uploadVideoOpen} onOpenChange={setUploadVideoOpen}>
        <DialogContent className="bg-slate-950 border border-purple-500/30 text-white rounded-3xl max-w-lg mx-auto p-6">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent flex items-center gap-2">
              <Upload className="w-5 h-5 text-pink-400" />
              Importar Vídeo ou Áudio (MP3/MP4)
            </DialogTitle>
          </DialogHeader>

          {uploadSuccess ? (
            <div className="bg-purple-950/80 border border-purple-500/40 rounded-2xl p-6 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto" />
              <p className="text-sm font-medium text-purple-100">{uploadSuccess}</p>
            </div>
          ) : (
            <form onSubmit={handleUploadSubmit} className="space-y-4 pt-2">
              <div>
                <label className="text-xs font-medium text-purple-200 mb-1.5 block">Categoria</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "meditacao", label: "Meditação" },
                    { id: "oracao", label: "Oração" },
                    { id: "motivacao", label: "Motivação" },
                  ].map(cat => (
                    <Button
                      key={cat.id}
                      type="button"
                      variant={mediaCategory === cat.id ? "default" : "outline"}
                      onClick={() => setMediaCategory(cat.id as any)}
                      className={`text-xs rounded-xl h-9 capitalize ${
                        mediaCategory === cat.id 
                          ? "bg-purple-600 text-white border-purple-500" 
                          : "bg-slate-900 text-purple-300 border-purple-500/20 hover:bg-purple-900/40"
                      }`}
                    >
                      {cat.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Título do Conteúdo</label>
                <Input
                  value={mediaTitle}
                  onChange={e => setMediaTitle(e.target.value)}
                  placeholder="Ex: Oração da Manhã e Paz Interior"
                  className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Descrição acolhedora</label>
                <Textarea
                  value={mediaDesc}
                  onChange={e => setMediaDesc(e.target.value)}
                  placeholder="Breve resumo sobre o arquivo..."
                  className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 rounded-xl min-h-[80px]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Duração estimada</label>
                <Input
                  value={mediaDuration}
                  onChange={e => setMediaDuration(e.target.value)}
                  placeholder="Ex: 5 min"
                  className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 rounded-xl"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-purple-200 mb-1 block">Arquivo de Mídia (MP3 ou MP4, máx. 50MB)</label>
                <Input
                  type="file"
                  accept="audio/mp3,audio/mpeg,video/mp4"
                  onChange={e => handleFileChange(e)}
                  className="bg-slate-900 border-purple-500/30 text-white file:bg-purple-600 file:text-white file:rounded-xl file:border-0 file:text-xs file:py-1 file:px-3 rounded-xl cursor-pointer"
                  required
                />
                {mediaFileName && (
                  <span className="text-xs text-pink-300 mt-1 block">Arquivo selecionado: {mediaFileName}</span>
                )}
              </div>

              <div className="flex justify-end pt-2">
                <Button
                  type="submit"
                  disabled={uploadVideoMutation.isPending || !mediaFileBase64}
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium rounded-xl px-6 w-full"
                >
                  {uploadVideoMutation.isPending ? "Enviando e salvando..." : "Importar e Publicar"}
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {authOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-slate-950 border border-purple-500/30 rounded-3xl p-6 shadow-2xl">
            <Button 
              variant="ghost" 
              onClick={() => setAuthOpen(false)}
              className="absolute top-4 right-4 text-purple-300 hover:text-white rounded-full h-8 w-8 p-0"
            >
              ✕
            </Button>
            <AuthModal onSuccess={() => setAuthOpen(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

function CommentSection({ postId, user, setAuthOpen }: { postId: number; user: any; setAuthOpen: (open: boolean) => void }) {
  const [commentText, setCommentText] = useState("");
  const { data: comments = [], isLoading } = trpc.community.listComments.useQuery({ postId });
  const utils = trpc.useUtils();
  const createCommentMutation = trpc.community.createComment.useMutation({
    onSuccess: () => {
      setCommentText("");
      utils.community.listComments.invalidate({ postId });
      utils.community.listPosts.invalidate();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthOpen(true);
      return;
    }
    if (!commentText || commentText.trim().length < 2) return;
    createCommentMutation.mutate({ postId, content: commentText, isAnonymous: false });
  };

  return (
    <div className="bg-slate-950/60 p-4 border-t border-purple-500/10 space-y-4">
      <h4 className="text-xs font-semibold text-purple-300 uppercase tracking-wider">Acolhimento & Respostas</h4>
      
      {isLoading ? (
        <div className="text-xs text-purple-400/60 py-2">Carregando comentários...</div>
      ) : comments.length === 0 ? (
        <div className="text-xs text-purple-400/60 italic py-1">Seja o primeiro a enviar uma palavra amiga para esta partilha.</div>
      ) : (
        <div className="space-y-3">
          {comments.map(c => (
            <div key={c.id} className="bg-slate-900/90 rounded-2xl p-3 border border-purple-500/10 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">{c.authorName}</span>
                <span className="text-[10px] text-purple-300/50">
                  {new Date(c.createdAt).toLocaleDateString("pt-BR", { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <p className="text-xs text-purple-100 leading-relaxed">{c.content}</p>
            </div>
          ))}
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex gap-2 pt-1">
        <Input
          value={commentText}
          onChange={e => setCommentText(e.target.value)}
          placeholder="Escreva uma palavra de apoio..."
          className="bg-slate-900 border-purple-500/30 text-white placeholder:text-purple-400/40 text-xs rounded-xl h-9"
        />
        <Button 
          type="submit" 
          disabled={createCommentMutation.isPending}
          size="sm"
          className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl h-9 px-4 text-xs shrink-0"
        >
          {createCommentMutation.isPending ? "..." : "Enviar"}
        </Button>
      </form>
    </div>
  );
}

function ReportButton({ postId, user, setAuthOpen }: { postId: number; user: any; setAuthOpen: (open: boolean) => void }) {
  const [reported, setReported] = useState(false);
  const reportMutation = trpc.community.reportPost.useMutation({
    onSuccess: () => setReported(true),
  });

  const handleReport = () => {
    if (!user) {
      setAuthOpen(true);
      return;
    }
    if (window.confirm("Deseja denunciar esta publicação por conteúdo inadequado ou sinal de risco?")) {
      reportMutation.mutate({ postId });
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={handleReport}
      disabled={reported || reportMutation.isPending}
      className="text-purple-300/60 hover:text-red-400 hover:bg-red-950/20 rounded-full h-8 px-2.5 text-xs gap-1"
      title="Denunciar publicação"
    >
      <Flag className="w-3.5 h-3.5" />
      <span>{reported ? "Denunciado" : "Denunciar"}</span>
    </Button>
  );
}
