import { BreathingExercise } from "@/components/BreathingExercise";
import { CrisisBanner } from "@/components/CrisisBanner";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/_core/hooks/useAuth";
import { LuminaAuthGate } from "@/components/LuminaAuthGate";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { THEMES } from "@shared/themes";
import { ArrowLeft, Loader2, Send, Sparkles, Wind } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "wouter";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

type LocalMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
};

// Tópicos expandidos para todos os temas, organizados exatamente para preencher os botões de ação rápida
const SUGGESTIONS: Record<string, string[]> = {
  saude_emocional: [
    "Tenho me sentido muito triste ultimamente",
    "Estou me sentindo sozinho(a) e sem apoio",
    "Sinto um cansaço físico e mental que não passa",
    "Preciso de ajuda para lidar com crises de ansiedade",
    "Como encontrar motivação nos dias difíceis?",
  ],
  relacionamentos: [
    "Estou em conflito com alguém que amo muito",
    "Tenho dificuldade em impor limites saudáveis",
    "Como perdoar uma mágoa antiga que ainda dói?",
    "Sinto que não sou compreendido(a) em casa",
    "Como superar o término de um relacionamento?",
  ],
  trabalho: [
    "Acho que estou chegando no estágio de burnout",
    "Sinto ansiedade e medo antes de trabalhar",
    "Não sei mais qual é o meu verdadeiro propósito",
    "Como lidar com a pressão e cobranças excessivas?",
    "Estou pensando em mudar de carreira mas tenho medo",
  ],
  apoio_espiritual: [
    "Estou em busca de paz interior e serenidade",
    "Sinto que perdi a esperança no amanhã",
    "Como encontrar sentido e resignificação no que vivi?",
    "Preciso de uma palavra de conforto e esperança",
    "Como fortalecer minha fé e conexão com a vida?",
  ],
  geral: [
    "Só preciso desabafar um pouco sobre o meu dia",
    "Quero organizar meus pensamentos e acalmar a mente",
    "Me ajuda a começar o dia com mais leveza?",
    "Estindo uma carga pesada nos ombros agora",
    "Quero apenas conversar com alguém que me escute",
  ],
};

export default function Chat() {
  const params = useParams<{ id: string }>();
  const conversationId = Number(params.id);
  const { isAuthenticated, loading: authLoading } = useAuth();

  const [localMessages, setLocalMessages] = useState<LocalMessage[]>([]);
  const [input, setInput] = useState("");
  const [showCrisis, setShowCrisis] = useState(false);
  const [showBreathing, setShowBreathing] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data, isLoading } = trpc.conversations.get.useQuery(
    { id: conversationId },
    { enabled: isAuthenticated && Number.isFinite(conversationId) },
  );

  const { data: affirmationData } = trpc.chat.dailyAffirmation.useQuery();
  const utils = trpc.useUtils();

  // Carrega histórico persistido ao abrir
  useEffect(() => {
    if (data?.messages) {
      setLocalMessages(
        data.messages.map(m => ({ id: String(m.id), role: m.role, content: m.content })),
      );
      // risk check handled by backend
    }
  }, [data?.messages]);

  const sendMutation = trpc.chat.send.useMutation({
    onSuccess: result => {
      setLocalMessages(prev => [
        ...prev,
        { id: `a-${Date.now()}`, role: "assistant", content: result.reply },
      ]);
      if (result.riskDetected) setShowCrisis(true);
      utils.conversations.list.invalidate();
    },
    onError: () => {
      toast.error("Não consegui responder agora. Tente novamente em instantes.");
    },
  });

  const handleSend = (content: string) => {
    const trimmed = content.trim();
    if (!trimmed || sendMutation.isPending) return;
    setLocalMessages(prev => [...prev, { id: `u-${Date.now()}`, role: "user", content: trimmed }]);
    setInput("");
    sendMutation.mutate({ conversationId, content: trimmed });
    textareaRef.current?.focus();
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [localMessages.length, sendMutation.isPending, showBreathing, showCrisis]);

  const theme = useMemo(
    () => THEMES.find(t => t.value === data?.conversation.topic),
    [data?.conversation.topic],
  );

  if (!authLoading && !isAuthenticated) {
    return (
      <LuminaAuthGate
        title="Entre para continuar"
        description="Entre na sua conta Lumina para abrir esta conversa e continuar em um espaço acolhedor."
      />
    );
  }

  return (
    <div className="flex h-dvh flex-col bg-background">
      {/* Header */}
      <header className="lumi-mesh shrink-0">
        <div className="container flex items-center justify-between py-3">
          <div className="flex min-w-0 items-center gap-2">
            <Link href="/conversas">
              <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20 hover:text-white" aria-label="Voltar">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div className="min-w-0">
              <p className="lumi-hero-text font-display truncate text-sm font-semibold">
                {theme ? `${theme.emoji} ${theme.label}` : "Conversa com a Lumina"}
              </p>
              <p className="truncate text-xs text-white/75">Lumina · uma luz ao seu lado</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowBreathing(v => !v)}
            className="shrink-0 rounded-full text-white hover:bg-white/20 hover:text-white"
          >
            <Wind className="mr-1.5 h-4 w-4" />
            Respirar
          </Button>
        </div>
      </header>

      {/* Mensagens */}
      <ScrollArea className="flex-1">
        <div className="container max-w-3xl space-y-4 py-6">
          {showCrisis && <CrisisBanner onClose={() => setShowCrisis(false)} />}
          {showBreathing && <BreathingExercise onClose={() => setShowBreathing(false)} />}

          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-16 w-2/3 rounded-2xl" />
              <Skeleton className="ml-auto h-12 w-1/2 rounded-2xl" />
              <Skeleton className="h-16 w-2/3 rounded-2xl" />
            </div>
          ) : localMessages.length === 0 ? (
            <div className="flex flex-col items-center gap-5 pt-6 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-400 via-violet-500 to-indigo-600 shadow-lg shadow-violet-200">
                <Sparkles className="h-6 w-6 text-white animate-pulse" />
              </div>
              <div>
                <h2 className="font-display text-lg font-semibold text-foreground">
                  Estou aqui com você
                </h2>
                <p className="mx-auto mt-1 max-w-sm text-xs text-muted-foreground">
                  Este é um espaço seguro e sem julgamentos. Pode começar como preferir.
                </p>
              </div>
              {affirmationData && (
                <div className="w-full max-w-md rounded-2xl border border-violet-200 bg-violet-50/80 px-4 py-3 shadow-sm">
                  <p className="lumi-subtitle text-[10px] font-semibold text-violet-500 tracking-wider uppercase">
                    Afirmação de hoje
                  </p>
                  <p className="mt-1 text-sm font-medium italic text-violet-900">
                    “{affirmationData.affirmation}”
                  </p>
                </div>
              )}
              {/* Tópicos rápidos que ao clicar enviam automaticamente a mensagem */}
              <div className="flex w-full max-w-md flex-col gap-2.5 px-2">
                {(SUGGESTIONS[data?.conversation.topic ?? "geral"] ?? SUGGESTIONS.geral).map(s => (
                  <button
                    key={s}
                    onClick={() => handleSend(s)}
                    disabled={sendMutation.isPending}
                    className="w-full rounded-2xl border border-violet-200 bg-white/90 py-3 px-4 text-sm font-medium text-violet-800 shadow-sm transition-all duration-150 hover:bg-violet-50 hover:border-violet-300 active:scale-[0.98] disabled:opacity-50 text-center"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            localMessages.map(message => (
              <div
                key={message.id}
                className={cn(
                  "flex items-start gap-3",
                  message.role === "user" ? "justify-end" : "justify-start",
                )}
              >
                {message.role === "assistant" && (
                  <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-400 via-violet-500 to-indigo-600 shadow-sm">
                    <Sparkles className="h-4 w-4 text-white" />
                  </div>
                )}
                <div
                  className={cn(
                    "max-w-[82%] rounded-2xl px-4 py-3 shadow-sm text-sm leading-relaxed",
                    message.role === "user"
                      ? "bg-violet-600 text-white rounded-tr-sm"
                      : "bg-card border border-border text-card-foreground rounded-tl-sm",
                  )}
                >
                  {message.role === "assistant" ? (
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <Streamdown>{message.content}</Streamdown>
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap">{message.content}</p>
                  )}
                </div>
              </div>
            ))
          )}

          {sendMutation.isPending && (
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-400 via-violet-500 to-indigo-600">
                <Sparkles className="h-4 w-4 text-white animate-spin" />
              </div>
              <div className="rounded-2xl rounded-tl-sm border border-border bg-card px-4 py-3 text-sm text-muted-foreground shadow-sm">
                <span className="inline-flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-purple-500 animate-bounce"></span>
                  <span className="h-2 w-2 rounded-full bg-pink-500 animate-bounce [animation-delay:0.2s]"></span>
                  <span className="h-2 w-2 rounded-full bg-amber-500 animate-bounce [animation-delay:0.4s]"></span>
                  <span className="ml-1">A Lumina está ouvindo e preparando uma resposta com carinho...</span>
                </span>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      {/* Input Footer */}
      <footer className="shrink-0 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 p-3">
        <div className="container max-w-3xl">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend(input);
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(input);
                  }
                }}
                placeholder="Escreva o que estiver sentindo..."
                rows={1}
                className="max-h-24 min-h-11 w-full resize-none rounded-full border-input bg-muted/50 px-4 py-3 pr-12 text-sm focus-visible:ring-violet-500"
              />
              <Button
                type="submit"
                size="icon"
                disabled={!input.trim() || sendMutation.isPending}
                className="absolute right-1.5 top-1.5 h-8 w-8 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md hover:from-purple-700 hover:to-pink-700 disabled:opacity-50"
              >
                {sendMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </form>
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            A Lumina é uma assistente virtual e não substitui ajuda profissional. Em crise, ligue{" "}
            <a href="tel:188" className="font-semibold text-violet-600 underline underline-offset-2">
              188 / cvv.org.br
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}
