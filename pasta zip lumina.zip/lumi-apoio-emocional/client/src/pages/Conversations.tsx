import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { LuminaAuthGate } from "@/components/LuminaAuthGate";
import { trpc } from "@/lib/trpc";
import { THEMES } from "@shared/themes";
import { ArrowLeft, Loader2, LogOut, MessageCircleHeart, Settings, Trash2, Sparkles } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

const THEME_LABEL_MAP = Object.fromEntries(THEMES.map(t => [t.value, t]));

export default function Conversations() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [, navigate] = useLocation();
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [creatingTheme, setCreatingTheme] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const { data: conversations, isLoading } = trpc.conversations.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createMutation = trpc.conversations.create.useMutation({
    onSuccess: data => {
      utils.conversations.list.invalidate();
      navigate(`/chat/${data.id}`);
    },
    onError: () => {
      toast.error("Não foi possível iniciar a conversa. Tente novamente.");
      setCreatingTheme(null);
    },
  });

  const deleteMutation = trpc.conversations.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.conversations.list.cancel();
      const previous = utils.conversations.list.getData();
      utils.conversations.list.setData(undefined, old => old?.filter(c => c.id !== id));
      return { previous };
    },
    onError: (_err, _vars, context) => {
      utils.conversations.list.setData(undefined, context?.previous);
      toast.error("Não foi possível excluir a conversa.");
    },
    onSettled: () => utils.conversations.list.invalidate(),
  });

  if (!loading && !isAuthenticated) {
    return (
      <LuminaAuthGate
        title="Entre para conversar com a Lumina"
        description="Entre para salvar suas conversas e continuar de onde parou em um espaço acolhedor e protegido."
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="lumi-mesh">
        <div className="container flex items-center justify-between py-5">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20 hover:text-white">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <span className="lumi-hero-text font-display text-xl font-bold">Lumina</span>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/comunidade">
              <Button variant="ghost" className="rounded-full text-white hover:bg-white/20 hover:text-white text-xs gap-1.5 px-3 bg-white/10 border border-white/20">
                <Sparkles className="h-4 w-4 text-pink-300" />
                <span>Comunidade</span>
              </Button>
            </Link>
            <Link href="/configuracoes">
              <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20 hover:text-white" aria-label="Configurações">
                <Settings className="h-5 w-5" />
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full text-white hover:bg-white/20 hover:text-white"
              aria-label="Sair"
              onClick={() => logout()}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
        <div className="container pb-10">
          <h1 className="lumi-hero-text font-display text-3xl font-bold md:text-4xl">
            Olá{user?.name ? `, ${user.name.split(" ")[0]}` : ""} 💜
          </h1>
          <p className="lumi-hero-text mt-1 opacity-90">Sobre o que você gostaria de conversar hoje?</p>
        </div>
      </header>

      <main className="container -mt-6 pb-16">
        {/* Seletor de tema */}
        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {THEMES.map(theme => (
            <button
              key={theme.value}
              disabled={createMutation.isPending}
              onClick={() => {
                setCreatingTheme(theme.value);
                createMutation.mutate({ topic: theme.value });
              }}
              className="group rounded-2xl border bg-card p-5 text-left shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-violet-300 hover:shadow-md active:scale-[0.98] disabled:opacity-60"
            >
              <div className="flex items-center justify-between">
                <span className="text-2xl">{theme.emoji}</span>
                {createMutation.isPending && creatingTheme === theme.value && (
                  <Loader2 className="h-4 w-4 animate-spin text-violet-500" />
                )}
              </div>
              <h3 className="font-display mt-3 font-semibold text-foreground">{theme.label}</h3>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{theme.description}</p>
            </button>
          ))}
        </section>

        {/* Histórico */}
        <section className="mt-12">
          <h2 className="font-display text-lg font-semibold text-foreground">Suas conversas</h2>
          {isLoading ? (
            <div className="mt-4 space-y-3">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-16 w-full rounded-2xl" />
              ))}
            </div>
          ) : !conversations || conversations.length === 0 ? (
            <div className="mt-4 flex flex-col items-center gap-3 rounded-2xl border border-dashed py-12 text-center">
              <MessageCircleHeart className="h-10 w-10 text-violet-300" />
              <p className="text-sm text-muted-foreground">
                Você ainda não tem conversas. Escolha um tema acima para começar.
              </p>
            </div>
          ) : (
            <ul className="mt-4 space-y-3">
              {conversations.map(conv => {
                const theme = THEME_LABEL_MAP[conv.topic];
                return (
                  <li key={conv.id}>
                    <div className="flex items-center gap-3 rounded-2xl border bg-card p-4 shadow-sm transition-colors hover:border-violet-300">
                      <Link
                        href={`/chat/${conv.id}`}
                        className="flex min-w-0 flex-1 items-center gap-3"
                      >
                        <span className="text-xl">{theme?.emoji ?? "💬"}</span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate font-medium text-foreground">{conv.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {theme?.label ?? conv.topic} ·{" "}
                            {new Date(conv.updatedAt).toLocaleString("pt-BR", {
                              day: "2-digit",
                              month: "short",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Excluir conversa"
                        className="shrink-0 rounded-full text-muted-foreground hover:bg-rose-50 hover:text-rose-600"
                        onClick={() => setDeleteId(conv.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </main>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir conversa?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. Todas as mensagens desta conversa serão removidas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 hover:bg-rose-700"
              onClick={() => {
                if (deleteId !== null) deleteMutation.mutate({ id: deleteId });
                setDeleteId(null);
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
