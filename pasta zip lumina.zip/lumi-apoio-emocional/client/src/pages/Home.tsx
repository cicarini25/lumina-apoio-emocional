import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { HeartHandshake, MessageCircleHeart, Sparkles, Wind } from "lucide-react";
import { Link, useLocation } from "wouter";
import { AuthModal } from "@/components/AuthModal";
import { Dialog, DialogContent } from "@/components/ui/dialog";

const FEATURES = [
  {
    icon: MessageCircleHeart,
    title: "Escuta ativa",
    text: "Conversas empáticas e sem julgamentos, no seu tempo e do seu jeito.",
  },
  {
    icon: Wind,
    title: "Respiração guiada",
    text: "Exercícios de calma e presença integrados diretamente ao chat.",
  },
  {
    icon: Sparkles,
    title: "Afirmações diárias",
    text: "Pequenas palavras de força e gentileza para começar o seu dia.",
  },
  {
    icon: HeartHandshake,
    title: "Espaço seguro",
    text: "Suas conversas são suas. Apoio em crise com o CVV sempre à mão.",
  },
];

export default function Home() {
  const [showOpening, setShowOpening] = useState(
    () => new URLSearchParams(window.location.search).get("skipOpening") !== "1",
  );
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const { data: affirmationData } = trpc.chat.dailyAffirmation.useQuery();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authDefaultTab, setAuthDefaultTab] = useState<"login" | "register">("login");

  useEffect(() => {
    const openingTimer = window.setTimeout(() => setShowOpening(false), 7000);
    return () => window.clearTimeout(openingTimer);
  }, []);

  const handleStart = () => {
    if (isAuthenticated) {
      navigate("/conversas");
    } else {
      setAuthDefaultTab("login");
      setAuthModalOpen(true);
    }
  };

  const handleOpenAuth = (tab: "login" | "register" = "login") => {
    setAuthDefaultTab(tab);
    setAuthModalOpen(true);
  };

  if (showOpening) {
    return (
      <div
        className="lumi-opening lumi-mesh lumi-mesh-animated flex min-h-screen items-center justify-center px-6"
        role="status"
        aria-label="Abrindo Lumina Apoio Emocional"
      >
        <div className="lumi-opening-card flex w-full max-w-sm flex-col items-center rounded-[2rem] p-4 sm:p-6">
          <img
            src="/manus-storage/IMG_20260804_183109_bdfd1631.jpg"
            alt="Lumina — Ouvir, Acolher, Compreender, Caminhar ao seu lado"
            className="lumi-opening-logo h-auto w-full rounded-[1.5rem] object-contain"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="lumi-mesh lumi-mesh-animated min-h-screen">
      {/* Nav */}
      <header className="flex items-center justify-between px-6 py-5 md:px-12">
        <div className="flex flex-col">
          <span className="lumi-hero-text font-display text-2xl font-bold tracking-tight">Lumina</span>
        </div>
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <Link href="/conversas">
              <Button className="lumi-glass rounded-full text-white hover:bg-white/25">
                Minhas conversas
              </Button>
            </Link>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                onClick={() => handleOpenAuth("register")}
                variant="ghost"
                className="text-white hover:bg-white/15 rounded-full"
              >
                Cadastrar
              </Button>
              <Button
                onClick={() => handleOpenAuth("login")}
                disabled={loading}
                className="lumi-glass rounded-full text-white hover:bg-white/25"
              >
                Entrar
              </Button>
            </div>
          )}
        </div>
      </header>

      {/* Segunda página: conteúdo principal sem repetir a capa */}
      <main className="flex flex-col items-center px-6 pb-20 pt-14 text-center md:pt-24">
        <p className="lumi-subtitle lumi-hero-text mb-6 text-xs font-medium md:text-sm">
          Uma luz para ouvir, acolher e caminhar ao seu lado
        </p>
        <h1 className="lumi-hero-text font-display max-w-3xl text-5xl font-extrabold leading-tight md:text-7xl">
          Um espaço seguro para o que você sente
        </h1>
        <p className="lumi-hero-text mt-6 max-w-xl text-lg font-light opacity-90 md:text-xl">
          A Lumina está aqui para te ouvir com carinho — nos dias leves e nos dias difíceis.
        </p>
        <Button
          size="lg"
          onClick={handleStart}
          disabled={loading}
          className="mt-10 rounded-full bg-white px-10 py-6 text-lg font-semibold text-violet-800 shadow-xl shadow-black/20 transition-transform duration-150 hover:bg-white/90 active:scale-95"
        >
          Conversar com a Lumina
        </Button>

        {affirmationData && (
          <div className="lumi-glass mt-14 max-w-md rounded-2xl px-6 py-4">
            <p className="lumi-subtitle text-[10px] font-semibold text-white/80">
              Afirmação de hoje
            </p>
            <p className="lumi-hero-text mt-1.5 text-base font-medium italic">
              “{affirmationData.affirmation}”
            </p>
          </div>
        )}

        {/* Features */}
        <section className="mt-20 grid w-full max-w-5xl grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map(f => (
            <div key={f.title} className="lumi-glass rounded-2xl p-6 text-left">
              <f.icon className="h-7 w-7 text-white" />
              <h3 className="lumi-hero-text font-display mt-3 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-white/85">{f.text}</p>
            </div>
          ))}
        </section>

        {/* Aviso de papel */}
        <p className="mt-16 max-w-lg text-xs leading-relaxed text-white/70">
          A Lumina é uma assistente virtual de apoio e escuta — ela não substitui psicólogos,
          psiquiatras ou atendimento médico. Em caso de crise, ligue para o CVV:{" "}
          <a href="tel:188" className="font-semibold text-white underline underline-offset-2">
            188 / cvv.org.br
          </a>
          .
        </p>
      </main>

      {/* Modal de Autenticação da Lumina */}
      <Dialog open={authModalOpen} onOpenChange={setAuthModalOpen}>
        <DialogContent className="sm:max-w-md bg-transparent border-none p-0 shadow-none">
          <AuthModal
            defaultTab={authDefaultTab}
            onSuccess={() => {
              setAuthModalOpen(false);
              navigate("/conversas");
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
