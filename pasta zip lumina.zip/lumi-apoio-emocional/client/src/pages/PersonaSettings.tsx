import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { LuminaAuthGate } from "@/components/LuminaAuthGate";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Loader2, RotateCcw, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function PersonaSettings() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [value, setValue] = useState("");
  const [loaded, setLoaded] = useState(false);

  const { data, isLoading } = trpc.settings.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (data && !loaded) {
      setValue(data.customPersonaPrompt ?? "");
      setLoaded(true);
    }
  }, [data, loaded]);

  const saveMutation = trpc.settings.save.useMutation({
    onSuccess: () => toast.success("Personalidade da Lumina atualizada com carinho 💜"),
    onError: () => toast.error("Não foi possível salvar. Tente novamente."),
  });

  if (!authLoading && !isAuthenticated) {
    return (
      <LuminaAuthGate
        title="Personalize sua Lumina"
        description="Entre com sua conta e confirme sua presença para acessar suas preferências com privacidade."
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="lumi-mesh">
        <div className="container flex items-center gap-3 py-5">
          <Link href="/conversas">
            <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20 hover:text-white" aria-label="Voltar">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="lumi-hero-text font-display text-xl font-bold">Personalizar a Lumina</h1>
            <p className="text-xs text-white/80">Ajuste o jeito de ser da sua companheira de apoio</p>
          </div>
        </div>
      </header>

      <main className="container max-w-2xl py-8">
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h2 className="font-display font-semibold text-foreground">Prompt de personalidade</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Escreva como você gostaria que a Lumina se comportasse: tom de voz, estilo de acolhimento,
            temas favoritos. Deixe em branco para usar a personalidade padrão, empática e
            acolhedora. As regras de segurança (protocolo de crise com CVV) permanecem sempre
            ativas, independentemente do que for escrito aqui.
          </p>
          {isLoading && !loaded ? (
            <Skeleton className="mt-4 h-48 w-full rounded-xl" />
          ) : (
            <Textarea
              value={value}
              onChange={e => setValue(e.target.value)}
              placeholder="Ex.: Seja uma companheira serena e poética, que usa metáforas da natureza para acolher…"
              className="mt-4 min-h-48 rounded-xl"
              maxLength={8000}
            />
          )}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button
              onClick={() => saveMutation.mutate({ customPersonaPrompt: value || null })}
              disabled={saveMutation.isPending}
              className="rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 hover:opacity-90"
            >
              {saveMutation.isPending ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-1.5 h-4 w-4" />
              )}
              Salvar
            </Button>
            <Button
              variant="outline"
              className="rounded-full"
              disabled={saveMutation.isPending || !value}
              onClick={() => {
                setValue("");
                saveMutation.mutate({ customPersonaPrompt: null });
              }}
            >
              <RotateCcw className="mr-1.5 h-4 w-4" />
              Restaurar padrão
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
