import { HeartHandshake, Phone, X } from "lucide-react";
import { useState } from "react";

/**
 * Banner do protocolo de crise — exibido quando conteúdo de risco é detectado.
 * Contato exato exigido: "188 / cvv.org.br".
 */
export function CrisisBanner({ onClose }: { onClose?: () => void }) {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;

  return (
    <div
      role="alert"
      className="relative rounded-2xl border border-rose-200 bg-rose-50 p-4 shadow-sm animate-in fade-in slide-in-from-top-2 duration-300"
    >
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-rose-100">
          <HeartHandshake className="h-5 w-5 text-rose-600" />
        </div>
        <div className="flex-1 space-y-1.5">
          <p className="font-semibold text-rose-800">Você não está sozinho(a). Sua vida importa.</p>
          <p className="text-sm text-rose-700">
            Se você está passando por um momento muito difícil, o CVV — Centro de Valorização da
            Vida oferece apoio emocional gratuito e sigiloso, 24 horas por dia.
          </p>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <a
              href="tel:188"
              className="inline-flex items-center gap-1.5 rounded-full bg-rose-600 px-4 py-1.5 text-sm font-semibold text-white transition-transform duration-150 hover:bg-rose-700 active:scale-95"
            >
              <Phone className="h-3.5 w-3.5" />
              188 / cvv.org.br
            </a>
            <a
              href="https://cvv.org.br"
              target="_blank"
              rel="noreferrer"
              className="text-sm font-medium text-rose-700 underline underline-offset-2 hover:text-rose-900"
            >
              Acessar cvv.org.br
            </a>
          </div>
        </div>
        <button
          aria-label="Fechar aviso"
          className="rounded-full p-1 text-rose-400 transition-colors hover:bg-rose-100 hover:text-rose-600"
          onClick={() => {
            setVisible(false);
            onClose?.();
          }}
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
