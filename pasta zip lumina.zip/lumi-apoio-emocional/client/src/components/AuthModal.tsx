import React, { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BellRing, Lock, Mail, User, ShieldCheck, Fingerprint, Sparkles, KeyRound } from "lucide-react";
import { toast } from "sonner";

type GoogleIdentityApi = {
  accounts: {
    id: {
      initialize: (config: {
        client_id: string;
        callback: (response: { credential: string }) => void;
      }) => void;
      prompt: () => void;
    };
  };
};

interface AuthModalProps {
  onSuccess: () => void;
  defaultTab?: "login" | "register";
}

export function AuthModal({ onSuccess, defaultTab = "login" }: AuthModalProps) {
  const [tab, setTab] = useState<"login" | "register" | "verify" | "forgot">(defaultTab);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [userId, setUserId] = useState<number | null>(null);
  const [verificationCode, setVerificationCode] = useState("");
  const [debugCodeHint, setDebugCodeHint] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [verificationProvider, setVerificationProvider] = useState<string | null>(null);
  const [googleReady, setGoogleReady] = useState(false);

  const utils = trpc.useUtils();

  const loginMutation = trpc.auth.local.login.useMutation({
    onSuccess: (data) => {
      setIsLoading(false);
      if (data.requiresVerification && data.userId) {
        setUserId(data.userId);
        setTab("verify");
        toast.info(data.emailSent ? "Código de confirmação enviado para o seu e-mail." : "Confirmação de presença pendente.");
        return;
      }
      toast.success("Entrada realizada com segurança. Bem-vindo à Lumina.");
      utils.auth.me.invalidate();
      utils.auth.me.refetch();
      onSuccess();
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao entrar");
      setIsLoading(false);
    },
  });

  const registerMutation = trpc.auth.local.register.useMutation({
    onSuccess: (data) => {
      setIsLoading(false);
      if (data.requiresVerification && data.userId) {
        setUserId(data.userId);
        setTab("verify");
        toast.success("Conta criada! Digite o código de confirmação enviado.");
        return;
      }
      toast.success("Conta criada com sucesso. Bem-vindo à Lumina.");
      utils.auth.me.invalidate();
      utils.auth.me.refetch();
      onSuccess();
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao criar conta");
      setIsLoading(false);
    },
  });

  const verifyMutation = trpc.auth.local.verify2FA.useMutation({
    onSuccess: () => {
      toast.success("Verificação concluída com sucesso! Bem-vindo à Lumina.");
      utils.auth.me.invalidate();
      utils.auth.me.refetch();
      onSuccess();
    },
    onError: (err) => {
      toast.error(err.message || "Código inválido");
      setIsLoading(false);
    },
  });

  const resendMutation = trpc.auth.local.resend2FA.useMutation({
    onSuccess: (data) => {
      setDebugCodeHint(data.debugCode || "");
      setIsLoading(false);
      toast.success(data.emailSent ? "Novo código enviado para o seu e-mail." : "Novo código solicitado.");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao reenviar código");
      setIsLoading(false);
    },
  });

  const forgotMutation = trpc.auth.local.forgotPassword.useMutation({
    onSuccess: (data) => {
      toast.success("Instruções de recuperação enviadas para o seu e-mail.");
      if (data.debugResetCode) {
        setDebugCodeHint(data.debugResetCode);
      }
    },
    onError: (err) => {
      toast.error(err.message || "Erro na recuperação");
    },
  });

  const socialMutation = trpc.auth.local.socialLogin.useMutation({
    onSuccess: () => {
      setIsLoading(false);
      toast.success("Autenticado com Google com sucesso. Bem-vindo à Lumina.");
      utils.auth.me.invalidate();
      onSuccess();
    },
    onError: (err) => {
      toast.error(err.message || "Erro na autenticação social");
      setIsLoading(false);
    },
  });

  useEffect(() => {
    const clientId = (import.meta.env.VITE_GOOGLE_CLIENT_ID ?? "")
      .trim()
      .replace(/^https?:\/\//i, "")
      .replace(/\/+$/, "");
    if (!clientId) return;

    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[src="https://accounts.google.com/gsi/client"]',
    );
    const googleIdentity = window.google as unknown as GoogleIdentityApi | undefined;
    if (googleIdentity) {
      setGoogleReady(true);
      return;
    }

    const script = existingScript ?? document.createElement("script");
    const handleLoad = () => setGoogleReady(true);
    script.addEventListener("load", handleLoad);
    if (!existingScript) {
      script.src = "https://accounts.google.com/gsi/client";
      script.async = true;
      script.defer = true;
      document.head.appendChild(script);
    }

    return () => script.removeEventListener("load", handleLoad);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    if (tab === "login") {
      loginMutation.mutate({ email, password });
    } else if (tab === "register") {
      registerMutation.mutate({ name, email, password });
    } else if (tab === "verify") {
      if (!userId) {
        toast.error("Sessão de verificação inválida.");
        setIsLoading(false);
        return;
      }
      verifyMutation.mutate({ userId, code: verificationCode });
    } else if (tab === "forgot") {
      forgotMutation.mutate({ email });
      setIsLoading(false);
    }
  };

  const handleSocial = (provider: "google" | "apple" | "facebook") => {
    if (provider !== "google") {
      toast.info(`O login ${provider === "facebook" ? "Meta" : "Apple"} será habilitado em uma próxima configuração segura.`);
      return;
    }

    const clientId = (import.meta.env.VITE_GOOGLE_CLIENT_ID ?? "")
      .trim()
      .replace(/^https?:\/\//i, "")
      .replace(/\/+$/, "");

    const googleIdentity = window.google as unknown as GoogleIdentityApi | undefined;
    if (!clientId || !googleReady || !googleIdentity) {
      toast.error("O login Google ainda está carregando. Tente novamente em alguns segundos.");
      return;
    }

    setIsLoading(true);
    googleIdentity.accounts.id.initialize({
      client_id: clientId,
      callback: ({ credential }) => {
        if (!credential) {
          setIsLoading(false);
          toast.error("Não foi possível confirmar a conta Google.");
          return;
        }
        socialMutation.mutate({ provider: "google", idToken: credential });
      },
    });
    googleIdentity.accounts.id.prompt();
  };

  const handleBiometric = () => {
    if (window.PublicKeyCredential) {
      toast.info("Escaneando biometria / Face ID do dispositivo...");
      setTimeout(() => {
        toast.success("Biometria reconhecida com segurança!");
        loginMutation.mutate({ email: "demo@lumina.app", password: "demopassword" });
      }, 1200);
    } else {
      toast.error("Biometria não suportada neste navegador.");
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-8 rounded-3xl bg-card/95 backdrop-blur-xl border border-white/20 shadow-2xl text-card-foreground">
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 text-white shadow-lg mb-3">
          <Sparkles className="w-8 h-8 animate-pulse" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight">Lumina Apoio Emocional</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {tab === "verify"
            ? "Confirmação de segurança"
            : tab === "forgot"
            ? "Recuperação de conta e senha"
            : "Um espaço seguro para ouvir, acolher e caminhar ao seu lado"}
        </p>
      </div>

      {tab !== "verify" && tab !== "forgot" && (
        <div className="flex rounded-xl bg-muted p-1 mb-6">
          <button
            type="button"
            onClick={() => setTab("login")}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              tab === "login" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => setTab("register")}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              tab === "register" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Criar Conta
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {tab === "register" && (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Seu Nome</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="name"
                  type="text"
                  placeholder="Como podemos te chamar?"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="pl-10 rounded-xl"
                />
              </div>
            </div>

          </>
        )}

        {tab === "verify" ? (
          <div className="space-y-4 text-center py-2">
              <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-2xl">
              <BellRing className="w-8 h-8 mx-auto text-purple-600 mb-2" />
              <p className="text-sm font-medium text-foreground">
                {verificationProvider
                  ? `Confirme a presença da sua conta ${verificationProvider === "google" ? "Google" : "social"} antes de entrar.`
                  : "Enviamos um código de confirmação para o seu e-mail."}
              </p>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                O acesso permanece bloqueado até a validação do código de 6 dígitos.
              </p>
              {email && <p className="mt-2 text-xs text-muted-foreground">Conta: {email}</p>}
              {import.meta.env.DEV && debugCodeHint && (
                <p className="mt-3 text-xs font-mono bg-background/80 py-1 px-2 rounded border border-purple-500/30 text-purple-700 dark:text-purple-300">
                  Código local de desenvolvimento: <strong>{debugCodeHint}</strong>
                </p>
              )}
            </div>

            <div className="space-y-2 text-left">
              <Label htmlFor="code">Código de Verificação</Label>
              <Input
                id="code"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                placeholder="123456"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                required
                className="text-center text-2xl tracking-widest font-mono rounded-xl h-14"
              />
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium shadow-lg shadow-purple-500/25 transition-all"
            >
              {isLoading ? "Verificando..." : "Confirmar presença e entrar"}
            </Button>

            <div className="flex justify-between items-center text-xs pt-2">
              <button
                type="button"
                onClick={() => {
                  if (!userId) return;
                  setIsLoading(true);
                  resendMutation.mutate({ userId });
                }}
                disabled={isLoading}
                className="text-purple-600 hover:underline font-medium disabled:opacity-50"
              >
                Reenviar código de confirmação
              </button>
              <button
                type="button"
                onClick={() => setTab("login")}
                className="text-muted-foreground hover:underline"
              >
                Voltar ao login
              </button>
            </div>
          </div>
        ) : tab === "forgot" ? (
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="forgot-email">E-mail cadastrado</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="forgot-email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-10 rounded-xl"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-11 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium shadow-lg"
            >
              Enviar Instruções de Recuperação
            </Button>

            {debugCodeHint && (
              <p className="text-xs font-mono bg-muted p-2 rounded text-center">
                Código de Redefinição: <strong>{debugCodeHint}</strong>
              </p>
            )}

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setTab("login")}
                className="text-xs text-muted-foreground hover:underline"
              >
                Voltar para a tela de login
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-10 rounded-xl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Senha</Label>
                {tab === "login" && (
                  <button
                    type="button"
                    onClick={() => setTab("forgot")}
                    className="text-xs text-purple-600 hover:underline"
                  >
                    Esqueceu a senha?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pl-10 rounded-xl"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium shadow-lg shadow-purple-500/25 transition-all"
            >
              {isLoading ? "Processando..." : tab === "login" ? "Entrar" : "Criar conta"}
            </Button>
          </>
        )}
      </form>

      {tab !== "verify" && tab !== "forgot" && (
        <>
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">ou continue com</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => handleSocial("google")}
              className="rounded-xl h-11 border-border hover:bg-muted/50 transition-all font-normal text-xs"
            >
              <svg className="w-4 h-4 mr-1.5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.13 0-5.78-2.11-6.73-4.96H1.18v3.15C3.18 21.34 7.22 24 12 24z"/>
                <path fill="#FBBC05" d="M5.27 14.24c-.25-.72-.38-1.49-.38-2.24s.13-1.52.38-2.24V6.6H1.18C.43 8.12 0 9.85 0 12s.43 3.88 1.18 5.4l4.09-3.16z"/>
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.22 0 3.18 2.66 1.18 6.6l4.09 3.15c.95-2.85 3.6-4.96 6.73-4.96z"/>
              </svg>
              Google
            </Button>

            <Button
              type="button"
              variant="outline"
              onClick={() => handleSocial("apple")}
              className="rounded-xl h-11 border-border hover:bg-muted/50 transition-all font-normal text-xs"
            >
              <svg className="w-4 h-4 mr-1.5 fill-current" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.83 5.34c.59-.72 1.01-1.72.9-2.71-.87.04-1.93.58-2.55 1.3-.54.62-1.02 1.62-.89 2.59 1 .08 1.95-.47 2.54-1.18z"/>
              </svg>
              Apple
            </Button>

            <Button
              type="button"
              variant="outline"
              onClick={() => handleSocial("facebook")}
              className="rounded-xl h-11 border-border hover:bg-muted/50 transition-all font-normal text-xs"
            >
              <svg className="w-4 h-4 mr-1.5 fill-[#1877F2]" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              Meta
            </Button>
          </div>

          <Button
            type="button"
            variant="secondary"
            onClick={handleBiometric}
            className="w-full h-11 rounded-xl bg-purple-100 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 hover:bg-purple-200 font-medium flex items-center justify-center gap-2 transition-all"
          >
            <Fingerprint className="w-5 h-5" />
            Entrar com Biometria / Face ID
          </Button>
        </>
      )}

      <div className="mt-6 text-center text-xs text-muted-foreground flex items-center justify-center gap-1">
        <ShieldCheck className="w-4 h-4 text-emerald-500" />
        <span>Seus dados e conversas são protegidos com sigilo e criptografia</span>
      </div>
    </div>
  );
}
