import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

/**
 * Exercício de respiração guiada integrado ao chat.
 * Ciclo: inspire (4s) → segure (2s) → expire (6s), repetido.
 */
const PHASES = [
  { label: "Inspire pelo nariz…", duration: 4000 },
  { label: "Segure suavemente…", duration: 2000 },
  { label: "Expire devagar pela boca…", duration: 6000 },
] as const;

const TOTAL_CYCLE = PHASES.reduce((s, p) => s + p.duration, 0);

export function BreathingExercise({ onClose }: { onClose: () => void }) {
  const [phaseIndex, setPhaseIndex] = useState(0);
  const [cycles, setCycles] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    timerRef.current = setTimeout(() => {
      const next = (phaseIndex + 1) % PHASES.length;
      setPhaseIndex(next);
      if (next === 0) setCycles(c => c + 1);
    }, PHASES[phaseIndex].duration);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [phaseIndex]);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-violet-200 bg-gradient-to-br from-violet-50 via-fuchsia-50 to-orange-50 p-6 text-center shadow-sm animate-in fade-in duration-300">
      <button
        aria-label="Fechar exercício"
        onClick={onClose}
        className="absolute right-3 top-3 rounded-full p-1 text-violet-400 transition-colors hover:bg-violet-100 hover:text-violet-600"
      >
        <X className="h-4 w-4" />
      </button>
      <p className="font-display text-sm font-semibold uppercase tracking-widest text-violet-500">
        Respiração guiada
      </p>
      <div className="my-6 flex items-center justify-center">
        <div
          className="flex h-36 w-36 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-400 via-violet-500 to-indigo-600 shadow-lg shadow-violet-300/50"
          style={{
            animation: `lumi-breathe ${TOTAL_CYCLE}ms ease-in-out infinite`,
          }}
        >
          <div className="h-24 w-24 rounded-full bg-white/25 backdrop-blur-sm" />
        </div>
      </div>
      <p aria-live="polite" className="min-h-6 text-lg font-medium text-violet-800">
        {PHASES[phaseIndex].label}
      </p>
      <p className="mt-1 text-sm text-violet-500">
        {cycles === 0
          ? "Siga o movimento do círculo no seu ritmo."
          : `${cycles} ${cycles === 1 ? "ciclo completo" : "ciclos completos"} — continue enquanto for bom para você.`}
      </p>
      <Button
        variant="outline"
        size="sm"
        onClick={onClose}
        className="mt-4 border-violet-300 text-violet-700 hover:bg-violet-100"
      >
        Me sinto melhor
      </Button>
    </div>
  );
}
