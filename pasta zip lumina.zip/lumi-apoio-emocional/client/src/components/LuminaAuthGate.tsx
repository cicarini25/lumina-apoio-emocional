import { AuthModal } from "@/components/AuthModal";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ArrowLeft, ShieldCheck, Sparkles } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

type LuminaAuthGateProps = {
  title: string;
  description: string;
  backHref?: string;
};

export function LuminaAuthGate({ title, description, backHref = "/" }: LuminaAuthGateProps) {
  const [open, setOpen] = useState(false);
  const [defaultTab, setDefaultTab] = useState<"login" | "register">("login");

  return (
    <div className="lumi-mesh flex min-h-screen flex-col items-center justify-center gap-6 px-6 py-10 text-center">
      <div className="lumi-glass w-full max-w-lg rounded-[2rem] p-8 sm:p-10">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 text-white shadow-lg">
          <Sparkles className="h-8 w-8" aria-hidden="true" />
        </div>
        <p className="lumi-subtitle mt-6 text-xs font-semibold text-white/80">LUMINA AUTH</p>
        <h1 className="lumi-hero-text mt-2 font-display text-3xl font-bold">{title}</h1>
        <p className="lumi-hero-text mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/85">{description}</p>

        <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Button
            onClick={() => {
              setDefaultTab("login");
              setOpen(true);
            }}
            className="rounded-full bg-white px-7 text-violet-800 shadow-lg hover:bg-white/90"
          >
            Entrar
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setDefaultTab("register");
              setOpen(true);
            }}
            className="rounded-full border-white/40 bg-white/10 px-7 text-white hover:bg-white/20 hover:text-white"
          >
            Criar minha conta
          </Button>
        </div>

        <div className="mt-7 flex items-center justify-center gap-2 text-xs text-white/75">
          <ShieldCheck className="h-4 w-4 text-emerald-200" aria-hidden="true" />
          <span>Seu espaço protegido por autenticação Lumina</span>
        </div>
      </div>

      <Link href={backHref} className="lumi-hero-text inline-flex items-center gap-2 text-sm underline underline-offset-4 opacity-85">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        Voltar ao início
      </Link>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="border-none bg-transparent p-0 shadow-none sm:max-w-md">
          <AuthModal defaultTab={defaultTab} onSuccess={() => setOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
