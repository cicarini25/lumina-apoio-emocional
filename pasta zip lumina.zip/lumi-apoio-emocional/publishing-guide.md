# Guia de Publicação nas Lojas (Google Play e App Store) — Lumina

Este documento detalha o processo completo, os requisitos e as instruções para submeter o aplicativo **Lumina Apoio Emocional** ao Google Play e à App Store.

---

## 1. Visão Geral da Arquitetura Móvel

O Lumina foi integrado ao **Capacitor**, permitindo que a interface web (React + Tailwind) e o backend empacotado funcionem nativamente no Android e no iOS.

- **Identidade do App**: `com.lumiapp.apoioemocional`
- **Nome Exibido**: Lumina Apoio Emocional
- **Plataformas Configuradas**: Android (`/android`) e iOS (`/ios`)

---

## 2. Google Play Console (Android)

### Requisitos Prévios
1. Conta de Desenvolvedor Google Play (taxa única de cadastro de US$ 25) [1].
2. Para novas contas pessoais criadas após novembro de 2023, é obrigatório concluir testes fechados com pelo menos 20 testadores por 14 dias antes do lançamento público [2].

### Passos para Publicação
1. **Gerar o Build de Produção (AAB)**:
   - Abra o projeto no Android Studio (`npx cap open android`).
   - No menu superior, vá em **Build > Build Bundle(s) / APK(s) > Build Bundle(s)(s)**.
   - O arquivo gerado será o `.aab` (Android App Bundle), otimizado para distribuição [3].
2. **Criar o Aplicativo no Play Console**:
   - Acesse o [Google Play Console](https://play.google.com/console) [4].
   - Clique em **Todos os apps > Criar app**.
   - Defina o nome como `Lumina Apoio Emocional`, idioma padrão (Português do Brasil) e tipo (Aplicativo, gratuito).
3. **Preencher Ficha da Loja e Configurações**:
   - **Descrição Curta**: "Sua assistente de apoio emocional com escuta ativa e acolhimento."
   - **Descrição Completa**: Detalhar as funcionalidades da Lumina (temas de apoio, respiração, afirmações, protocolo de crise com CVV 188).
   - **Gráficos**: Ícone oficial (512x512), imagem de destaque (1024x500) e capturas de tela (mínimo 2 por dispositivo).
   - **Política de Privacidade**: Inserir o link da política de privacidade hospedada no seu domínio.
4. **Envio e Revisão**:
   - Envie o `.aab` na faixa de produção ou testes fechados, preencha o questionário de classificação etária e envie para revisão da Google.

---

## 3. App Store Connect (iOS)

### Requisitos Prévios
1. Conta no Apple Developer Program (assinatura anual de US$ 99).
2. Computador Mac com Xcode instalado para compilar e assinar o pacote iOS.

### Passos para Publicação
1. **Abrir o Projeto no Xcode**:
   - Execute `npx cap open ios` no terminal.
   - Selecione sua equipe de desenvolvimento (Developer Team) nas configurações de assinatura (Signing & Capabilities).
2. **Configurar Metadados no App Store Connect**:
   - Acesse o [App Store Connect](https://appstoreconnect.apple.com/) [5].
   - Crie um novo app com o Bundle ID `com.lumiapp.apoioemocional`.
   - Preencha o nome, subtítulo, categorias e preço (Gratuito).
   - Insira os detalhes de privacidade do app (Nutrition Label) declarando o uso de dados de autenticação e histórico de conversas [6].
3. **Enviar a Compilação**:
   - No Xcode, selecione **Any iOS Device (ARM64)**, vá em **Product > Archive**.
   - Após o término, use o Organizer para enviar o app via **Distribute App** para o TestFlight ou App Store Connect.
4. **Testes Beta e Revisão**:
   - Cadastre testadores no TestFlight para validação interna e externa [7].
   - Envie para a revisão da Apple (App Review), garantindo que as diretrizes de privacidade e saúde mental sejam rigorosamente respeitadas [8].

---

## 4. Recomendações de Conformidade (Saúde e Apoio Emocional)
- **Aviso de Isenção de Responsabilidade**: Mantenha visível no app que a Lumina é uma assistente virtual de apoio e não substitui acompanhamento psicológico ou psiquiátrico profissional.
- **Protocolo de Crise**: Certifique-se de que o contato de emergência (CVV - 188 / cvv.org.br) esteja acessível e operante quando necessário.

---

### Referências
1. [Google Play Console — Criar conta de desenvolvedor](https://support.google.com/googleplay/android-developer/answer/6112435?hl=pt-br)
2. [Google Play Console — Requisitos de teste para novas contas](https://support.google.com/googleplay/android-developer/answer/14151465)
3. [Google Play Console — Android App Bundles](https://support.google.com/googleplay/android-developer/answer/9844279)
4. [Google Play Console](https://play.google.com/console)
5. [App Store Connect](https://developer.apple.com/app-store-connect/)
6. [Apple — App Privacy Details](https://developer.apple.com/app-store/app-privacy-details/)
7. [Apple — TestFlight](https://developer.apple.com/testflight/)
8. [Apple — App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
