# Guia de Configuração de Domínio Próprio — Lumina Apoio Emocional

Para dar um aspecto 100% profissional ao Lumina e atender aos requisitos de URLs oficiais exigidos pelo Google Play e App Store (como a Política de Privacidade), a utilização de um domínio personalizado (ex.: `luminaapoioemocional.com.br`) é altamente recomendada.

---

## 1. Escolha e Registro do Domínio
1. **Sugestões de Nomes**:
   - `luminaapoio.com.br`
   - `applumina.com.br`
   - `luminaapoioemocional.com.br`
2. **Onde Registrar**:
   - No Brasil, o Registro.br gerencia domínios `.com.br`.
   - Provedores internacionais como GoDaddy, Namecheap ou Hostinger para `.com`.

---

## 2. Passo a Passo para Vincular ao Projeto Lumina

O painel de gerenciamento do projeto possui suporte integrado para domínios personalizados através da seção **Settings → Domains**.

1. **Acessar o Painel**:
   - Abra o Management UI do Lumina no canto superior direito.
   - Navegue até **Settings > Domains**.
2. **Adicionar o Domínio**:
   - Insira o seu domínio adquirido (ex.: `luminaapoioemocional.com.br`).
3. **Configurar os Registros DNS**:
   - O painel exibirá as instruções de apontamento (geralmente um registro **CNAME** ou **A**).
   - Acesse o painel da sua registradora de domínios (Registro.br, Hostinger, etc.) na seção de **Zona DNS**.
   - Adicione os registros informados pelo sistema.
4. **Validação e SSL (HTTPS)**:
   - Assim que o DNS propagar, o certificado de segurança SSL será emitido automaticamente, garantindo conexão segura (`https://`).

---

## 3. Vantagens do Domínio Próprio para o App
- **Credibilidade**: Transmite maior segurança aos usuários que buscam apoio emocional.
- **Conformidade com as Lojas**: Permite hospedar a Política de Privacidade e os Termos de Uso em endereços oficiais (`https://seu-dominio.com.br/privacy`), facilitando a aprovação no Google Play e na App Store.
- **Continuidade**: O endereço em `manus.space` continua funcionando em paralelo até que o domínio próprio esteja totalmente ativo.
