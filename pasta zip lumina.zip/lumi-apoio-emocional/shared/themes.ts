/** Temas de conversa compartilhados entre cliente e servidor */
export const THEMES = [
  {
    value: "saude_emocional",
    label: "Saúde Emocional",
    description: "Tristeza, solidão, cansaço e reconexão consigo",
    emoji: "🌱",
  },
  {
    value: "relacionamentos",
    label: "Relacionamentos",
    description: "Comunicação, limites saudáveis e superação de mágoas",
    emoji: "💞",
  },
  {
    value: "trabalho",
    label: "Trabalho",
    description: "Burnout, ansiedade, propósito e equilíbrio",
    emoji: "🧭",
  },
  {
    value: "apoio_espiritual",
    label: "Apoio Espiritual",
    description: "Paz interior, sentido e fortalecimento da esperança",
    emoji: "✨",
  },
  {
    value: "geral",
    label: "Conversa Aberta",
    description: "Um espaço livre para o que você quiser compartilhar",
    emoji: "💬",
  },
] as const;

export type ThemeValue = (typeof THEMES)[number]["value"];
