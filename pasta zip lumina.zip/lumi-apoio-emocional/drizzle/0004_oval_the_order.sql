CREATE TABLE `communityComments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`postId` int NOT NULL,
	`userId` int NOT NULL,
	`authorName` varchar(128) NOT NULL DEFAULT 'Membro Lumina',
	`isAnonymous` boolean NOT NULL DEFAULT false,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `communityComments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `communityPosts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`authorName` varchar(128) NOT NULL DEFAULT 'Membro Lumina',
	`isAnonymous` boolean NOT NULL DEFAULT false,
	`category` enum('desabafos','conquistas','reflexoes','conselhos','gratidao') NOT NULL DEFAULT 'desabafos',
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`likesCount` int NOT NULL DEFAULT 0,
	`commentsCount` int NOT NULL DEFAULT 0,
	`riskFlagged` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `communityPosts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wellbeingVideos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`youtubeId` varchar(64) NOT NULL,
	`category` varchar(64) NOT NULL DEFAULT 'motivacao',
	`duration` varchar(32) NOT NULL DEFAULT '5 min',
	`featured` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wellbeingVideos_id` PRIMARY KEY(`id`)
);
