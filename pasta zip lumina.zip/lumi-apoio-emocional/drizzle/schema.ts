import { mysqlTable, varchar, text, int, timestamp, boolean, mysqlEnum } from "drizzle-orm/mysql-core";

/** Usuários do sistema */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 64 }),
  provider: varchar("provider", { length: 64 }).default("manus").notNull(),
  loginMethod: varchar("loginMethod", { length: 64 }).default("manus").notNull(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  twoFactorCode: varchar("twoFactorCode", { length: 8 }),
  twoFactorMethod: varchar("twoFactorMethod", { length: 32 }).default("email").notNull(),
  twoFactorExpiresAt: varchar("twoFactorExpiresAt", { length: 64 }),
  isVerified: boolean("isVerified").default(false).notNull(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  lastSignedIn: timestamp("lastSignedIn"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Conversas de chat com a Lumina */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  topic: mysqlEnum("topic", ["saude_emocional", "relacionamentos", "trabalho", "apoio_espiritual", "geral"]).default("geral").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/** Mensagens das conversas */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/** Configurações de persona e preferências do usuário */
export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  personaName: varchar("personaName", { length: 64 }).default("Lumina").notNull(),
  slogan: varchar("slogan", { length: 255 }).default("Uma luz para ouvir, acolher e caminhar ao seu lado").notNull(),
  voiceEnabled: boolean("voiceEnabled").default(true).notNull(),
  themeColor: varchar("themeColor", { length: 32 }).default("purple").notNull(),
  customPersonaPrompt: text("customPersonaPrompt"),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;

/** Categorias de posts na comunidade */
export const communityCategories = [
  "desabafos",
  "conquistas",
  "reflexoes",
  "conselhos",
  "gratidao",
] as const;

/** Posts da comunidade de apoio */
export const communityPosts = mysqlTable("communityPosts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  authorName: varchar("authorName", { length: 128 }).notNull().default("Membro Lumina"),
  isAnonymous: boolean("isAnonymous").default(false).notNull(),
  category: mysqlEnum("category", communityCategories).default("desabafos").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  likesCount: int("likesCount").default(0).notNull(),
  commentsCount: int("commentsCount").default(0).notNull(),
  riskFlagged: boolean("riskFlagged").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = typeof communityPosts.$inferInsert;

/** Comentários nas publicações da comunidade */
export const communityComments = mysqlTable("communityComments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  authorName: varchar("authorName", { length: 128 }).notNull().default("Membro Lumina"),
  isAnonymous: boolean("isAnonymous").default(false).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityComment = typeof communityComments.$inferSelect;
export type InsertCommunityComment = typeof communityComments.$inferInsert;

/** Mensagens do chat de interação da comunidade */
export const communityMessages = mysqlTable("communityMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  authorName: varchar("authorName", { length: 128 }).notNull().default("Membro Lumina"),
  isAnonymous: boolean("isAnonymous").default(true).notNull(),
  content: text("content").notNull(),
  riskFlagged: boolean("riskFlagged").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityMessage = typeof communityMessages.$inferSelect;
export type InsertCommunityMessage = typeof communityMessages.$inferInsert;

/** Curtidas/Apoios em posts da comunidade */
export const communityLikes = mysqlTable("communityLikes", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityLike = typeof communityLikes.$inferSelect;
export type InsertCommunityLike = typeof communityLikes.$inferInsert;

/** Denúncias em posts da comunidade */
export const communityReports = mysqlTable("communityReports", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  reason: varchar("reason", { length: 255 }).default("Conteúdo inadequado").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityReport = typeof communityReports.$inferSelect;
export type InsertCommunityReport = typeof communityReports.$inferInsert;

/** Denúncias em mensagens do chat comunitário */
export const communityMessageReports = mysqlTable("communityMessageReports", {
  id: int("id").autoincrement().primaryKey(),
  messageId: int("messageId").notNull(),
  userId: int("userId").notNull(),
  reason: varchar("reason", { length: 255 }).default("Conteúdo inadequado").notNull(),
  status: varchar("status", { length: 32 }).default("pending").notNull(), // pending, resolved, dismissed
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityMessageReport = typeof communityMessageReports.$inferSelect;
export type InsertCommunityMessageReport = typeof communityMessageReports.$inferInsert;

/** Biblioteca de vídeos de bem-estar, oração e motivação */
export const wellbeingVideos = mysqlTable("wellbeingVideos", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  youtubeId: varchar("youtubeId", { length: 512 }).notNull(),
  category: varchar("category", { length: 64 }).notNull().default("motivacao"),
  duration: varchar("duration", { length: 32 }).notNull().default("5 min"),
  featured: boolean("featured").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WellbeingVideo = typeof wellbeingVideos.$inferSelect;
export type InsertWellbeingVideo = typeof wellbeingVideos.$inferInsert;
