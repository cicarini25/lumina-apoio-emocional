ALTER TABLE `users` ADD `phone` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `twoFactorCode` varchar(16);--> statement-breakpoint
ALTER TABLE `users` ADD `twoFactorMethod` varchar(16);--> statement-breakpoint
ALTER TABLE `users` ADD `twoFactorExpiresAt` varchar(64);--> statement-breakpoint
ALTER TABLE `users` ADD `isVerified` boolean DEFAULT false NOT NULL;