ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `provider` varchar(32) DEFAULT 'local' NOT NULL;